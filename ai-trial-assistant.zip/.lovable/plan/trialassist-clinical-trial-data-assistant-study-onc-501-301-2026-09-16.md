# TrialAssist — Clinical Trial Data Assistant (Study ONC-501-301)

A web application for clinical data managers and biostatisticians, rebuilt from the uploaded
TrialAssist project: same trial dataset, same study documents, same analysis methods.

## What gets built

### 1. Trial data warehouse (in the browser)
The real study data from the archive — 325 patients, 3,128 visits, 889 adverse events,
15,090 lab results, 320 biomarker records — is shipped with the app and loaded into an
in-browser SQLite engine (sql.js) on startup. Every number shown anywhere in the app comes
from a query against that data, not from hardcoded text.

### 2. AI Clinical Query Assistant (home page)
- Ask a question in plain language; quick-start chips for the five sample questions.
- A visible step-by-step trace of how the answer was produced: which tool ran
  (SQL Query, Documentation Search, Survival Analysis, Data Quality), the SQL generated,
  the rows returned, the statistics computed, and the passages cited.
- Answers carry citations back to the Protocol, Statistical Analysis Plan, Data Dictionary,
  and AE Definitions.
- **Works out of the box** with a built-in offline orchestrator: an intent router that matches
  the question, runs real SQL / Kaplan-Meier / data-quality routines against the loaded data,
  and writes a grounded answer. No key required.
- **Optional Groq key** in Settings: when present, the same tools are exposed to the Groq
  model, which chooses tools itself and writes the final answer. Key stays in the browser.

### 3. Survival analysis
Interactive Kaplan-Meier curves for Overall Survival and Progression-Free Survival,
ONC-501 vs Standard of Care: step curves with confidence bands, censoring ticks, median
survival lines, at-risk table, log-rank chi-square and p-value, median difference.
Kaplan-Meier, Greenwood variance, and the log-rank test are ported directly from the
Python implementation.

### 4. SQL workbench
Schema browser for all five tables, editable query editor with the sample queries,
read-only validation (SELECT/WITH only), result grid, row counts, CSV export.

### 5. Study documentation hub
Protocol, Statistical Analysis Plan, Data Dictionary, and AE Definitions, rendered with a
section outline and full-text search with highlighted matches.

### 6. Data quality & audit dashboard
All seven deterministic checks from the Python agent — duplicate patients, treatment-arm
conflicts, visits before enrollment, impossible lab values, missing PD-L1 by site, visit
sequence gaps, missing tumor assessments — with severity, affected IDs, the heuristic
quality score, AE-to-discontinuation reconciliation, and a per-site missing-biomarker table.

## Design
Clinical/biotech system: near-white and deep slate surfaces, a single clinical teal/blue
accent, restrained data-dense typography, tabular figures for all numbers, severity colors
reserved for findings only. Dense tables, calm charts, no marketing gloss.

## Technical notes
- Data files served from `public/data/` as CSV and parsed into sql.js at boot; a shared
  warehouse context exposes `query(sql)` to every page.
- `src/lib/stats.ts` — Kaplan-Meier, Greenwood CI, median survival, log-rank (port of
  `stats_agent.py`). `src/lib/dq.ts` — the seven checks (port of `data_quality_agent.py`).
  `src/lib/rag.ts` — section-chunked keyword/TF-IDF retrieval over the four documents
  (port of `rag_agent.py`). `src/lib/orchestrator.ts` — offline intent router producing
  answer + trace.
- Groq calls go through a server function so the request shape stays server-side; the user's
  key is sent from the browser only when they have configured one.
- Routes: `/` assistant, `/survival`, `/sql`, `/documents`, `/quality`, `/settings`.

## Not included
Data generation/regeneration (`generate_data.py`) — the app ships the already-generated
dataset, matching the archive.
