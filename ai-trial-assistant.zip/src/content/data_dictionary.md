# ONC-501-301 Data Dictionary

## Table: patients
One row per randomized patient (deliberate exceptions: a small number of
duplicate and arm-inconsistent rows exist as injected data quality issues
for the Data Quality Agent to detect; see `_injected_issues.json`).

| Field | Description |
|---|---|
| patient_id | Unique patient identifier, format ONC501-<site>-<seq> |
| site_id / site_name / region | Enrolling site and geographic region |
| treatment_arm | "ONC-501" or "Standard of Care" |
| age | Age in years at enrollment |
| sex | "Male" or "Female" |
| race | Self-reported race category |
| ecog_status | ECOG performance status at baseline (0, 1, or 2) |
| enrollment_date | Date of randomization (ISO 8601) |
| discontinuation_reason | One of: Death, Disease Progression, Adverse Event, Withdrawal by Subject, Physician Decision, Lost to Follow-up, Completed Study, Ongoing |
| discontinuation_date | Date of treatment discontinuation, blank if Ongoing |
| os_time_days | Overall survival time in days (randomization to death or censoring) |
| os_event | 1 = death observed, 0 = censored |
| pfs_time_days | Progression-free survival time in days |
| pfs_event | 1 = progression or death observed, 0 = censored |

## Table: visits
One row per scheduled tumor assessment visit per patient.

| Field | Description |
|---|---|
| patient_id | Foreign key to patients |
| visit_num | Sequential visit number, 0 = baseline |
| visit_date | Date of the visit |
| tumor_sod_mm | Sum of diameters of target lesions (mm) per RECIST v1.1; blank if the assessment was missed |
| baseline_sod_mm | Patient's baseline (Visit 0) sum of diameters, repeated on every row for convenience |

## Table: adverse_events
One row per reported adverse event.

| Field | Description |
|---|---|
| ae_id | Unique adverse event identifier |
| patient_id | Foreign key to patients |
| ae_term | Reported term (see AE Definitions document for grading conventions) |
| soc | MedDRA System Organ Class |
| grade | CTCAE v5.0 severity grade, 1 (mild) to 5 (fatal) |
| serious | Boolean; meets regulatory definition of a serious adverse event |
| related_to_treatment | Boolean; investigator-assessed causality to study treatment |
| onset_date / resolution_date | Event dates; resolution_date blank if unresolved at data cutoff |
| led_to_discontinuation | Boolean; whether this event caused treatment discontinuation |

## Table: labs
One row per lab test per scheduled visit.

| Field | Description |
|---|---|
| lab_id | Unique lab result identifier |
| patient_id / visit_num / visit_date | Linkage to visits |
| test_name | e.g. "ALT (U/L)", "Hemoglobin (g/dL)", "ANC (10^9/L)" |
| result_value | Measured value |
| ref_low / ref_high | Laboratory reference range for the test |

## Table: biomarkers
One row per patient, baseline biomarker testing.

| Field | Description |
|---|---|
| patient_id | Foreign key to patients |
| pd_l1_status | "Positive", "Negative", "Not Evaluable", or blank if the test was not performed/resulted |
| pd_l1_tps_pct | PD-L1 Tumor Proportion Score, percent, blank if not applicable |

Missingness in `pd_l1_status` is not uniform across sites; some sites have
a substantially higher missing rate, which is a known data quality
finding in this dataset (see `_injected_issues.json` and the Data Quality
Agent report for full detail -- note not all missingness is an injected
issue, some reflects genuine assay failure rates by site).
