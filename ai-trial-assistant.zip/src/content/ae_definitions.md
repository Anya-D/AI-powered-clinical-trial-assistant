# ONC-501-301 Adverse Event Definitions and Grading Conventions

## 1. Adverse Event (AE)
Any untoward medical occurrence in a patient administered a study
treatment, which does not necessarily have a causal relationship with
the treatment. An AE can therefore be any unfavorable and unintended
sign, symptom, or disease temporally associated with study participation.

## 2. Serious Adverse Event (SAE)
An adverse event is classified as serious if it results in any of the
following: death, a life-threatening event, inpatient hospitalization or
prolongation of existing hospitalization, persistent or significant
disability/incapacity, a congenital anomaly, or is otherwise considered
an important medical event by the investigator.

## 3. Severity Grading (CTCAE v5.0)
Adverse events in this study are graded using the Common Terminology
Criteria for Adverse Events (CTCAE) version 5.0, on a 1-5 scale:

| Grade | Definition |
|---|---|
| 1 | Mild; asymptomatic or mild symptoms; no intervention indicated |
| 2 | Moderate; minimal, local, or non-invasive intervention indicated |
| 3 | Severe or medically significant but not immediately life-threatening; hospitalization indicated |
| 4 | Life-threatening consequences; urgent intervention indicated |
| 5 | Death related to the adverse event |

"Grade 3+" or "high-grade" adverse events refer to events graded 3, 4, or
5 and are the primary focus of safety monitoring committee review.

## 4. Causality (Relatedness)
Investigators assess each AE for its causal relationship to study
treatment as: Not Related, Unlikely, Possible, Probable, or Definite.
For summary reporting purposes, "Possible," "Probable," and "Definite"
are collapsed into a single "Related" category.

## 5. Adverse Events Leading to Discontinuation
An adverse event is flagged as leading to discontinuation if it was the
documented primary reason the patient permanently discontinued study
treatment, per investigator assessment on the case report form.

## 6. Adverse Events of Special Interest for ONC-501
Given the immune-modulating mechanism of ONC-501, the following adverse
events are pre-specified as Adverse Events of Special Interest (AESI)
and receive enhanced monitoring and expedited reporting regardless of
assessed causality:
- Pneumonitis (any grade)
- Hepatotoxicity (Grade >= 2 transaminase elevation)
- Severe cutaneous reactions
- Endocrinopathies (thyroid, adrenal, pituitary dysfunction)

## 7. Laboratory Reference Ranges
Standard laboratory reference ranges used to flag abnormal results in
this study:

| Test | Reference Range |
|---|---|
| ALT (U/L) | 7 - 56 |
| AST (U/L) | 8 - 48 |
| Creatinine (mg/dL) | 0.6 - 1.3 |
| Hemoglobin (g/dL) | 12.0 - 17.5 |
| ANC, Absolute Neutrophil Count (10^9/L) | 1.5 - 8.0 |

A result is flagged as a Grade 3+ laboratory abnormality if it falls
outside these ranges by a clinically significant margin as defined per
CTCAE v5.0 criteria for the specific test.
