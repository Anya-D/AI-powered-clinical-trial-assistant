# ONC-501-301 Statistical Analysis Plan (Synopsis)

## 1. Analysis Populations
- **Intent-to-Treat (ITT) Population**: all randomized patients, analyzed
  according to their assigned treatment arm regardless of treatment
  actually received. Used for all efficacy analyses.
- **Safety Population**: all patients who received at least one dose of
  study treatment, analyzed according to treatment actually received.

## 2. Primary Endpoint Analysis: Overall Survival

Overall survival is defined as the time from the date of randomization to
the date of death from any cause. Patients who have not died at the time
of analysis are censored at the date they were last known to be alive.

OS will be estimated using the **Kaplan-Meier method** for each treatment
arm. The treatment arms will be compared using a **stratified log-rank
test** (stratified by the randomization factors: ECOG status, PD-L1
status, and region), with a two-sided alpha of 0.05. The hazard ratio and
its 95% confidence interval will be estimated using a stratified Cox
proportional hazards model. Median OS and the 12-month and 24-month
survival probabilities will be reported for each arm with 95% confidence
intervals derived via Greenwood's formula.

## 3. Secondary Endpoint Analysis: Progression-Free Survival

PFS is defined as the time from randomization to the first documented
radiographic progression per RECIST v1.1, or death from any cause,
whichever occurs first. Patients without a PFS event at the time of
analysis are censored at the date of their last evaluable tumor
assessment. The same Kaplan-Meier and stratified log-rank methodology
used for OS will be applied to PFS.

## 4. Objective Response Rate

ORR is defined as the proportion of ITT patients achieving a confirmed
complete response (CR) or partial response (PR) per RECIST v1.1 at any
point during the study. Response is derived from the sum of diameters
(SOD) of target lesions relative to baseline:
- Complete Response: disappearance of all target lesions
- Partial Response: >= 30% decrease in SOD from baseline
- Progressive Disease: >= 20% increase in SOD from nadir
- Stable Disease: neither PR nor PD criteria met

## 5. Safety Analyses

Adverse events will be summarized descriptively by treatment arm,
System Organ Class, and CTCAE grade, using the Safety Population. Special
attention will be given to adverse events of Grade 3 or higher, serious
adverse events, and adverse events leading to treatment discontinuation.
No formal hypothesis testing is planned for safety endpoints; between-arm
differences are reported descriptively.

## 6. Handling of Missing Data

For efficacy endpoints, no imputation is performed for censored
time-to-event data; standard Kaplan-Meier censoring rules apply. Missing
individual tumor assessments do not by themselves trigger censoring
unless two or more consecutive scheduled assessments are missed. Missing
biomarker (PD-L1) results are summarized descriptively by site and are
not imputed.

## 7. Interim Analysis

This synthetic dataset represents a pre-specified interim analysis. No
alpha spending adjustment is modeled in this demonstration; a real interim
analysis would apply a group sequential boundary (e.g., O'Brien-Fleming)
to control the overall type I error rate.
