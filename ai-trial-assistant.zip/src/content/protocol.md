# Protocol ONC-501: Study Protocol (Synopsis)

**Full Title:** A Randomized, Open-Label, Phase III Study of ONC-501 versus
Standard of Care in Patients with Advanced Non-Small Cell Lung Cancer (NSCLC)

**Protocol Number:** ONC-501-301
**Version:** 3.0 (Amendment 2)
**Sponsor:** Fictional Oncology Therapeutics, Inc. (synthetic data for
portfolio demonstration purposes only)

## 1. Study Design

This is a Phase III, multi-regional, randomized (1:1), open-label study
comparing ONC-501 to Standard of Care (investigator's choice
platinum-based chemotherapy) in patients with locally advanced or
metastatic NSCLC who have progressed on or after first-line therapy.

Randomization is stratified by ECOG performance status (0-1 vs. 2), PD-L1
expression status (Positive vs. Negative/Not Evaluable), and region
(North America, Europe, Asia-Pacific, Latin America).

## 2. Objectives and Endpoints

### 2.1 Primary Endpoint
**Overall Survival (OS)**, defined as the time from randomization to death
from any cause. Patients last known to be alive are censored at the date
of last contact.

### 2.2 Secondary Endpoints
- **Progression-Free Survival (PFS)**: time from randomization to the
  first documented radiographic disease progression (per RECIST v1.1) or
  death from any cause, whichever occurs first. Patients without a PFS
  event are censored at their last evaluable tumor assessment.
- **Objective Response Rate (ORR)**: proportion of patients with a
  confirmed complete or partial response per RECIST v1.1.
- **Duration of Response (DoR)**
- **Safety and tolerability**, characterized by the incidence, severity,
  and relatedness of adverse events per CTCAE v5.0.

## 3. Study Population

Approximately 320 patients are planned for enrollment across
approximately 12 sites in North America, Europe, Asia-Pacific, and Latin
America.

### 3.1 Key Inclusion Criteria
- Histologically confirmed locally advanced or metastatic NSCLC
- Progression on or after one prior line of platinum-based therapy
- ECOG performance status 0-2
- Measurable disease per RECIST v1.1
- Adequate hematologic, hepatic, and renal function

### 3.2 Key Exclusion Criteria
- Untreated or symptomatic central nervous system metastases
- Prior treatment with an agent in the same mechanistic class as ONC-501
- Active autoimmune disease requiring systemic immunosuppression
- Clinically significant cardiovascular disease within 6 months of
  randomization

## 4. Treatment Schedule and Visit Schema

Tumor assessments (CT or MRI) are performed at Screening, then every 6
weeks (+/- 7 days) from randomization through Week 48, then every 12
weeks thereafter, per RECIST v1.1, until documented disease progression.
Safety laboratory panels (hematology and chemistry) are collected at
every scheduled visit.

## 5. Discontinuation of Study Treatment

Patients discontinue study treatment for one of the following reasons,
which are recorded in the electronic case report form:
Disease Progression, Adverse Event, Withdrawal by Subject, Physician
Decision, Death, Lost to Follow-up, or Completed Study (per-protocol
treatment duration reached). Patients who discontinue treatment continue
to be followed for survival unless they formally withdraw consent.

## 6. Data Cutoff

This synthetic dataset represents an interim analysis snapshot; patients
enrolled later in the enrollment period may have shorter follow-up and
are recorded with discontinuation status "Ongoing" as of the data cutoff
date.
