import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronDown, Download } from "lucide-react";
import { toast } from "sonner";
import { useWarehouse } from "@/components/warehouse-provider";
import { LoadingWarehouse, PageHeader, Panel, SeverityBadge, Stat } from "@/components/primitives";
import { PlainNote } from "@/components/plain-english";
import { explainQuality, PAGE_PLAIN } from "@/lib/plain";
import { runDataQuality } from "@/lib/dq";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/quality")({
  head: () => ({
    meta: [
      { title: "Data Quality & Audit — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Deterministic discrepancy checks for study ONC-501-301: duplicate records, arm conflicts, invalid dates, implausible labs, missing biomarkers by site and AE reconciliation.",
      },
      { property: "og:title", content: "Data Quality & Audit — TrialAssist" },
      {
        property: "og:description",
        content:
          "Rule-based, reproducible data quality findings with affected identifiers and site-level missingness.",
      },
    ],
  }),
  component: QualityPage,
});

function QualityPage() {
  const { warehouse, loading } = useWarehouse();
  const report = useMemo(() => (warehouse ? runDataQuality(warehouse) : null), [warehouse]);
  const [expanded, setExpanded] = useState<string | null>(null);

  if (loading || !report) return <LoadingWarehouse />;

  const critical = report.findings.filter((f) => f.severity === "critical" && f.count > 0).length;
  const warnings = report.findings.filter((f) => f.severity === "warning" && f.count > 0).length;
  const rec = report.reconciliation;

  function exportReport() {
    if (!report) return;
    const lines = [
      "check,severity,count,detail",
      ...report.findings.map(
        (f) => `"${f.check}",${f.severity},${f.count},"${f.detail.replace(/"/g, '""')}"`,
      ),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "trialassist-data-quality.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Data quality report exported");
  }

  return (
    <div>
      <PageHeader
        title="Data Quality & Audit"
        description="Seven deterministic checks run against the warehouse every time this page loads. These are rule-based and reproducible by design — no model is involved in producing a finding."
        actions={
          <button
            type="button"
            onClick={exportReport}
            className="flex items-center gap-1.5 rounded-md border border-border bg-surface px-3 py-1.5 text-[12px] font-medium hover:bg-surface-strong"
          >
            <Download className="h-3.5 w-3.5" /> Export findings
          </button>
        }
      />

      <PlainNote
        className="mb-5"
        title={PAGE_PLAIN["quality"]!.title}
        lines={PAGE_PLAIN["quality"]!.lines}
      />

      <PlainNote className="mb-5" title="What the checks found" lines={explainQuality(report)} />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="Quality score"
          value={`${report.qualityScore}`}
          hint="Heuristic composite out of 100 — not a validated regulatory metric"
        />
        <Stat
          label="Patients checked"
          value={String(report.nPatients)}
          hint="Distinct patient_id values"
        />
        <Stat
          label="Critical findings"
          value={String(critical)}
          tone={critical ? "critical" : "default"}
          hint="Checks requiring query resolution"
        />
        <Stat
          label="Warnings"
          value={String(warnings)}
          tone={warnings ? "warning" : "default"}
          hint="Monitorable, non-blocking findings"
        />
      </div>

      <Panel
        title="Discrepancy findings"
        subtitle="Click a finding to see affected identifiers and the executed rule"
        bodyClassName="p-0"
        className="mb-5"
      >
        <ul>
          {report.findings.map((f) => {
            const open = expanded === f.check;
            return (
              <li key={f.check} className="border-b border-grid last:border-b-0">
                <button
                  type="button"
                  onClick={() => setExpanded(open ? null : f.check)}
                  className="flex w-full items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-surface-strong"
                >
                  <SeverityBadge severity={f.severity} />
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-medium">{f.check}</span>
                    <span className="mt-0.5 block text-[12px] leading-relaxed text-muted-foreground">
                      {f.detail}
                    </span>
                  </span>
                  <span className="shrink-0 text-[13px] font-semibold tnum">{f.count}</span>
                  <ChevronDown
                    className={cn(
                      "mt-0.5 h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                      open && "rotate-180",
                    )}
                  />
                </button>
                {open ? (
                  <div className="space-y-3 border-t border-grid bg-surface-strong/60 px-4 py-3">
                    {f.sql ? (
                      <div>
                        <div className="label-caps mb-1">Rule</div>
                        <pre className="overflow-x-auto rounded border border-border bg-surface p-2.5 font-mono text-[11.5px] leading-relaxed whitespace-pre-wrap">
                          {f.sql}
                        </pre>
                      </div>
                    ) : null}
                    {f.affectedIds.length ? (
                      <div>
                        <div className="label-caps mb-1">
                          Affected identifiers ({f.affectedIds.length})
                        </div>
                        <div className="flex max-h-40 flex-wrap gap-1 overflow-y-auto">
                          {f.affectedIds.slice(0, 200).map((id) => (
                            <span
                              key={id}
                              className="rounded border border-border bg-surface px-1.5 py-0.5 font-mono text-[11px]"
                            >
                              {id}
                            </span>
                          ))}
                          {f.affectedIds.length > 200 ? (
                            <span className="px-1.5 py-0.5 text-[11px] text-muted-foreground">
                              +{f.affectedIds.length - 200} more
                            </span>
                          ) : null}
                        </div>
                      </div>
                    ) : (
                      <p className="text-[12px] text-muted-foreground">
                        This check reports an aggregate rather than specific identifiers.
                      </p>
                    )}
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      </Panel>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel
          title="AE ↔ discontinuation reconciliation"
          subtitle="Do AE records flagged as discontinuation-causing match the patient-level reason?"
        >
          <dl className="space-y-2 text-[12.5px]">
            <ReconRow
              label="AE records flagged led_to_discontinuation"
              value={rec.aeDiscontinuationEvents}
            />
            <ReconRow
              label="Patients with such an AE record"
              value={rec.patientsWithAeDiscontinuationEvent}
            />
            <ReconRow
              label="Patients with discontinuation_reason = 'Adverse Event'"
              value={rec.patientsWithAeDiscontinuationReason}
            />
            <ReconRow
              label="Flagged AE but reason is not 'Adverse Event'"
              value={rec.unreconciled.length}
              tone={rec.unreconciled.length ? "warning" : "ok"}
            />
            <ReconRow
              label="Reason is 'Adverse Event' but no flagged AE"
              value={rec.orphanReason.length}
              tone={rec.orphanReason.length ? "warning" : "ok"}
            />
          </dl>

          {rec.unreconciled.length ? (
            <div className="mt-3 border-t border-border pt-3">
              <div className="label-caps mb-1.5">Unreconciled patients</div>
              <div className="flex max-h-32 flex-wrap gap-1 overflow-y-auto">
                {rec.unreconciled.map((id) => (
                  <span
                    key={id}
                    className="rounded border border-border bg-surface px-1.5 py-0.5 font-mono text-[11px]"
                  >
                    {id}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <p className="mt-3 border-t border-border pt-3 text-[12px] text-muted-foreground">
              Every AE flagged as leading to discontinuation reconciles with the patient-level
              discontinuation reason.
            </p>
          )}
        </Panel>

        <Panel
          title="Missing PD-L1 biomarker by site"
          subtitle="Missingness is not uniform across sites; the SAP requires it be reported descriptively"
          bodyClassName="p-0"
        >
          <div className="max-h-[420px] overflow-y-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Site</th>
                  <th className="text-right">Patients</th>
                  <th className="text-right">Missing</th>
                  <th className="text-right">% missing</th>
                  <th className="w-24">Rate</th>
                </tr>
              </thead>
              <tbody>
                {report.siteMissingness.map((s) => (
                  <tr key={s.site_id}>
                    <td className="whitespace-normal">
                      <span className="font-medium">{s.site_name}</span>
                    </td>
                    <td className="text-right tnum">{s.n_patients}</td>
                    <td className="text-right tnum">{s.n_missing}</td>
                    <td className="text-right tnum font-medium">{s.pct_missing}%</td>
                    <td>
                      <span className="block h-1.5 w-full rounded-full bg-grid">
                        <span
                          className={cn(
                            "block h-1.5 rounded-full",
                            s.pct_missing >= 25
                              ? "bg-critical"
                              : s.pct_missing >= 10
                                ? "bg-warning"
                                : "bg-primary",
                          )}
                          style={{ width: `${Math.min(100, s.pct_missing)}%` }}
                        />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function ReconRow({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: number;
  tone?: "default" | "warning" | "ok";
}) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-grid pb-1.5">
      <dt className="text-muted-foreground">{label}</dt>
      <dd
        className={cn(
          "font-semibold tnum",
          tone === "warning" && "text-warning",
          tone === "ok" && "text-primary",
        )}
      >
        {value}
      </dd>
    </div>
  );
}
