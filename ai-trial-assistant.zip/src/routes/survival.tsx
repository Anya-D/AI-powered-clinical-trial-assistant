import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useWarehouse } from "@/components/warehouse-provider";
import { AtRiskTable, KMChart } from "@/components/km-chart";
import { LoadingWarehouse, PageHeader, Panel, Stat } from "@/components/primitives";
import { PlainNote } from "@/components/plain-english";
import { explainSurvival, PAGE_PLAIN } from "@/lib/plain";
import { loadSurvivalRecords } from "@/lib/orchestrator";
import { daysToMonths, formatP, survivalAnalysis } from "@/lib/stats";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/survival")({
  head: () => ({
    meta: [
      { title: "Kaplan-Meier Survival Analysis — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Interactive Kaplan-Meier curves for overall and progression-free survival, ONC-501 versus standard of care, with medians, censoring ticks and log-rank statistics.",
      },
      { property: "og:title", content: "Kaplan-Meier Survival Analysis — TrialAssist" },
      {
        property: "og:description",
        content:
          "OS and PFS curves with Greenwood confidence bands, at-risk tables and log-rank p-values for study ONC-501-301.",
      },
    ],
  }),
  component: SurvivalPage,
});

function SurvivalPage() {
  const { warehouse, loading } = useWarehouse();
  const [endpoint, setEndpoint] = useState<"os" | "pfs">("os");
  const [xUnit, setXUnit] = useState<"days" | "months">("months");
  const [showCi, setShowCi] = useState(true);
  const [showCensors, setShowCensors] = useState(true);
  const [showMedian, setShowMedian] = useState(true);

  const analysis = useMemo(() => {
    if (!warehouse) return null;
    return survivalAnalysis(loadSurvivalRecords(warehouse, endpoint), endpoint);
  }, [warehouse, endpoint]);

  if (loading || !analysis) return <LoadingWarehouse />;

  const [treat, control] = analysis.curves;
  const diff = analysis.medianDifferenceDays;

  return (
    <div>
      <PageHeader
        title="Survival Analysis"
        description="Kaplan-Meier estimation with Greenwood confidence limits and a two-group log-rank test, computed in the browser from the intent-to-treat population. Censored patients are marked with ticks."
        actions={
          <div className="flex rounded-md border border-border bg-surface p-0.5">
            {(["os", "pfs"] as const).map((e) => (
              <button
                key={e}
                type="button"
                onClick={() => setEndpoint(e)}
                className={cn(
                  "rounded px-3 py-1.5 text-[12px] font-medium transition-colors",
                  endpoint === e
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {e === "os" ? "Overall Survival" : "Progression-Free Survival"}
              </button>
            ))}
          </div>
        }
      />

      <PlainNote
        className="mb-5"
        title={PAGE_PLAIN["survival"]!.title}
        lines={PAGE_PLAIN["survival"]!.lines}
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label={`Median ${endpoint.toUpperCase()} — ONC-501`}
          tone="treatment"
          value={treat?.median != null ? `${daysToMonths(treat.median).toFixed(1)} mo` : "NR"}
          hint={
            treat?.median != null
              ? `${treat.median} days · ${treat.events}/${treat.n} events`
              : "Not reached"
          }
        />
        <Stat
          label="Median — Standard of Care"
          tone="control"
          value={control?.median != null ? `${daysToMonths(control.median).toFixed(1)} mo` : "NR"}
          hint={
            control?.median != null
              ? `${control.median} days · ${control.events}/${control.n} events`
              : "Not reached"
          }
        />
        <Stat
          label="Median difference"
          value={diff != null ? `${diff > 0 ? "+" : ""}${daysToMonths(diff).toFixed(1)} mo` : "NE"}
          hint={
            diff != null
              ? `${diff > 0 ? "+" : ""}${diff} days in favour of ONC-501`
              : "Not estimable"
          }
        />
        <Stat
          label="Log-rank p-value"
          value={formatP(analysis.logrank.pValue)}
          hint={`χ² = ${analysis.logrank.chi2.toFixed(3)}, 1 df${
            analysis.logrank.hazardRatio != null
              ? ` · HR ${analysis.logrank.hazardRatio.toFixed(2)}`
              : ""
          }`}
        />
      </div>

      <PlainNote
        className="mb-5"
        title="What these results mean"
        lines={explainSurvival(analysis)}
      />

      <Panel
        title={`${analysis.endpointLabel} — Kaplan-Meier by treatment arm`}
        subtitle="Hover the plot to read survival probabilities at any timepoint."
        actions={
          <div className="flex flex-wrap items-center gap-3 text-[11.5px]">
            <Toggle label="95% CI band" checked={showCi} onChange={setShowCi} />
            <Toggle label="Censoring ticks" checked={showCensors} onChange={setShowCensors} />
            <Toggle label="Median lines" checked={showMedian} onChange={setShowMedian} />
            <button
              type="button"
              onClick={() => setXUnit((u) => (u === "days" ? "months" : "days"))}
              className="rounded border border-border bg-surface px-2 py-1 font-medium"
            >
              x-axis: {xUnit}
            </button>
          </div>
        }
      >
        <KMChart
          curves={analysis.curves}
          showCi={showCi}
          showCensors={showCensors}
          showMedian={showMedian}
          xUnit={xUnit}
        />
        <div className="mt-4 border-t border-border pt-3">
          <AtRiskTable curves={analysis.curves} xUnit={xUnit} />
        </div>
      </Panel>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Panel
          title="Landmark survival probabilities"
          subtitle="Kaplan-Meier estimate at fixed timepoints"
        >
          <table className="data-table">
            <thead>
              <tr>
                <th>Landmark</th>
                {analysis.curves.map((c) => (
                  <th key={c.label} className="text-right">
                    {c.label}
                  </th>
                ))}
                <th className="text-right">Difference</th>
              </tr>
            </thead>
            <tbody>
              {analysis.landmarks.map((l) => {
                const a = l.byArm[treat!.label];
                const b = l.byArm[control!.label];
                return (
                  <tr key={l.label}>
                    <td className="font-medium">{l.label}</td>
                    {analysis.curves.map((c) => (
                      <td key={c.label} className="text-right tnum">
                        {l.byArm[c.label] != null
                          ? `${(l.byArm[c.label]! * 100).toFixed(1)}%`
                          : "—"}
                      </td>
                    ))}
                    <td className="text-right tnum">
                      {a != null && b != null ? `${((a - b) * 100).toFixed(1)} pp` : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Panel>

        <Panel
          title="Method and test statistics"
          subtitle="Per the Statistical Analysis Plan, sections 2 and 3"
        >
          <dl className="space-y-2 text-[12.5px]">
            <Row label="Estimator" value="Kaplan-Meier product-limit" />
            <Row label="Variance" value="Greenwood's formula; log-log transformed 95% limits" />
            <Row
              label="Between-arm test"
              value="Two-group log-rank (Mantel-Cox), two-sided α = 0.05"
            />
            <Row label="Log-rank χ²" value={analysis.logrank.chi2.toFixed(4)} />
            <Row label="p-value" value={formatP(analysis.logrank.pValue)} />
            <Row
              label="Observed / expected (ONC-501)"
              value={`${analysis.logrank.observedA} / ${analysis.logrank.expectedA.toFixed(2)}`}
            />
            <Row
              label="Hazard ratio (O/E method)"
              value={
                analysis.logrank.hazardRatio != null
                  ? analysis.logrank.hazardRatio.toFixed(4)
                  : "n/a"
              }
            />
            <Row label="Median 95% CI — ONC-501" value={ciLabel(treat?.medianCi)} />
            <Row label="Median 95% CI — Standard of Care" value={ciLabel(control?.medianCi)} />
          </dl>
          <p className="mt-3 border-t border-border pt-3 text-[11.5px] leading-relaxed text-muted-foreground">
            The SAP specifies a log-rank stratified by ECOG status, PD-L1 status and region, and a
            stratified Cox model for the hazard ratio. This view reports the unstratified log-rank
            and an observed/expected hazard ratio approximation.
          </p>
        </Panel>
      </div>
    </div>
  );
}

function ciLabel(ci?: [number | null, number | null]) {
  if (!ci) return "n/a";
  const [lo, hi] = ci;
  const f = (v: number | null) => (v == null ? "NR" : `${daysToMonths(v).toFixed(1)} mo`);
  return `${f(lo)} – ${f(hi)}`;
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-grid pb-1.5">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium tnum">{value}</dd>
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-1.5">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-3.5 w-3.5 accent-[var(--primary)]"
      />
      {label}
    </label>
  );
}
