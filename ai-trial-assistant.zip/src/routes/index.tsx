import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { ArrowUp, BookMarked, Cpu, Sparkle } from "lucide-react";
import { useWarehouse } from "@/components/warehouse-provider";
import { TraceView } from "@/components/trace-view";
import { LoadingWarehouse, Panel, Stat } from "@/components/primitives";
import { PlainEnglishButton, PlainNote } from "@/components/plain-english";
import { explainAnswer, PAGE_PLAIN } from "@/lib/plain";
import {
  answerOffline,
  SAMPLE_QUESTIONS,
  type AgentAnswer,
  type TraceStep,
} from "@/lib/orchestrator";
import { answerWithGroq } from "@/lib/groq-agent";
import { readSettings } from "@/lib/settings";
import type { Warehouse } from "@/lib/warehouse";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Clinical Query Assistant — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Ask questions about study ONC-501-301 in plain language. The agent routes to SQL, protocol retrieval, Kaplan-Meier survival analysis or data quality checks, and shows every step.",
      },
      { property: "og:title", content: "AI Clinical Query Assistant — TrialAssist" },
      {
        property: "og:description",
        content:
          "Grounded answers over trial data with a full tool-selection trace: SQL, documentation RAG, survival analysis and data quality checks.",
      },
    ],
  }),
  component: AssistantPage,
});

interface Turn {
  id: number;
  question: string;
  answer?: AgentAnswer;
  liveTrace: TraceStep[];
  running: boolean;
  error?: string;
}

function AssistantPage() {
  const { warehouse, loading, error } = useWarehouse();
  const [question, setQuestion] = useState("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<{ groq: boolean; model: string }>({ groq: false, model: "" });
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const s = readSettings();
    setMode({ groq: Boolean(s.apiKey), model: s.model });
  }, []);

  useEffect(() => {
    if (!loading && !error) inputRef.current?.focus();
  }, [loading, error]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [turns]);

  async function ask(text: string) {
    const trimmed = text.trim();
    if (!trimmed || !warehouse || busy) return;
    const id = Date.now();
    setQuestion("");
    setBusy(true);
    setTurns((prev) => [...prev, { id, question: trimmed, liveTrace: [], running: true }]);

    try {
      const settings = readSettings();
      const result = settings.apiKey
        ? await answerWithGroq(warehouse, trimmed, settings.apiKey, settings.model, (step) =>
            setTurns((prev) =>
              prev.map((t) => (t.id === id ? { ...t, liveTrace: [...t.liveTrace, step] } : t)),
            ),
          )
        : await runOffline(warehouse, trimmed);
      setTurns((prev) =>
        prev.map((t) =>
          t.id === id ? { ...t, answer: result, running: false, liveTrace: [] } : t,
        ),
      );
    } catch (err) {
      setTurns((prev) =>
        prev.map((t) =>
          t.id === id ? { ...t, running: false, error: (err as Error).message } : t,
        ),
      );
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  }

  if (loading) return <LoadingWarehouse />;
  if (error) {
    return (
      <Panel title="Warehouse failed to load">
        <p className="text-[13px] text-critical">{error}</p>
      </Panel>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="min-w-0">
        <div className="mb-5">
          <h1 className="text-[22px] font-semibold tracking-tight">AI Clinical Query Assistant</h1>
          <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
            Ask about study ONC-501-301 in plain language. The agent decides which tool to use — SQL
            against the warehouse, retrieval from the protocol and SAP, Kaplan-Meier survival
            analysis, or the deterministic data quality battery — and shows every step it took.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface px-2.5 py-1 text-[11px] font-medium">
              <Cpu className="h-3 w-3 text-primary" />
              {mode.groq ? `Groq · ${mode.model}` : "Built-in orchestrator (offline)"}
            </span>
            {!mode.groq ? (
              <Link
                to="/settings"
                className="text-[11px] font-medium text-primary underline-offset-2 hover:underline"
              >
                Add a Groq API key for model-driven tool selection
              </Link>
            ) : null}
            <PlainEnglishButton />
          </div>
          <PlainNote
            className="mt-3"
            title={PAGE_PLAIN["assistant"]!.title}
            lines={PAGE_PLAIN["assistant"]!.lines}
          />
        </div>


        {turns.length === 0 ? (
          <div className="mb-5 rounded-lg border border-border bg-surface p-4">
            <div className="label-caps mb-2.5 flex items-center gap-1.5">
              <Sparkle className="h-3 w-3" /> Try one of these
            </div>
            <div className="flex flex-wrap gap-1.5">
              {SAMPLE_QUESTIONS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => void ask(q)}
                  className="rounded-full border border-border bg-surface-strong px-3 py-1.5 text-left text-[12px] transition-colors hover:border-primary/40 hover:bg-accent hover:text-accent-foreground"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        <div className="space-y-6">
          {turns.map((turn) => (
            <article key={turn.id} className="space-y-3">
              <div className="flex justify-end">
                <p className="max-w-[80%] rounded-lg rounded-br-sm bg-primary px-3.5 py-2.5 text-[13px] leading-relaxed text-primary-foreground">
                  {turn.question}
                </p>
              </div>

              {turn.running ? (
                <>
                  <TraceView steps={turn.liveTrace} running />
                  <p className="text-[13px] text-muted-foreground">Working through the tools…</p>
                </>
              ) : null}

              {turn.error ? (
                <p className="rounded-lg border border-critical/40 bg-critical/10 px-3 py-2.5 text-[13px] text-critical">
                  {turn.error}
                </p>
              ) : null}

              {turn.answer ? (
                <>
                  <TraceView steps={turn.answer.trace} />
                  <div className="rounded-lg border border-border bg-surface p-4">
                    <div className="label-caps mb-2">Answer</div>
                    <div className="space-y-2.5 text-[13.5px] leading-relaxed">
                      {turn.answer.answer.split("\n").map((line, i) =>
                        line.trim().startsWith(">") ? (
                          <blockquote
                            key={i}
                            className="border-l-2 border-primary/50 bg-surface-strong py-2 pl-3 text-[13px] text-muted-foreground italic"
                          >
                            {line.replace(/^>\s?/, "")}
                          </blockquote>
                        ) : line.trim() ? (
                          <p key={i}>{line}</p>
                        ) : null,
                      )}
                    </div>

                    {turn.answer.citations.length ? (
                      <div className="mt-3.5 border-t border-border pt-3">
                        <div className="label-caps mb-1.5 flex items-center gap-1.5">
                          <BookMarked className="h-3 w-3" /> Citations
                        </div>
                        <ul className="space-y-1">
                          {turn.answer.citations.map((c) => (
                            <li key={`${c.docId}-${c.section}`} className="text-[12px]">
                              <Link
                                to="/documents"
                                search={{ doc: c.docId, q: c.section }}
                                className="text-primary underline-offset-2 hover:underline"
                              >
                                {c.document} › {c.section}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : null}
                  </div>
                  <PlainNote
                    title="This answer in plain English"
                    lines={explainAnswer(turn.answer)}
                  />
                </>
              ) : null}
            </article>
          ))}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void ask(question);
          }}
          className="sticky bottom-4 mt-6"
        >
          <div className="rounded-xl border border-border bg-surface p-2 shadow-sm">
            <textarea
              ref={inputRef}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void ask(question);
                }
              }}
              rows={2}
              placeholder="Ask about enrollment, safety, survival, protocol definitions or data quality…"
              className="w-full resize-none bg-transparent px-2.5 py-2 text-[13.5px] leading-relaxed outline-none placeholder:text-muted-foreground"
            />
            <div className="flex items-center justify-between gap-2 px-1.5 pb-0.5">
              <span className="text-[11px] text-muted-foreground">
                Enter to send · Shift+Enter for a new line
              </span>
              <button
                type="submit"
                disabled={busy || !question.trim()}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-opacity disabled:opacity-40"
                aria-label="Send question"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
            </div>
          </div>
        </form>
      </div>

      <StudySidebar warehouse={warehouse} />
    </div>
  );
}

async function runOffline(wh: Warehouse, question: string): Promise<AgentAnswer> {
  // Yield to the browser so the trace placeholder paints before the work runs.
  await new Promise((resolve) => setTimeout(resolve, 120));
  return answerOffline(wh, question);
}

function StudySidebar({ warehouse }: { warehouse: Warehouse | null }) {
  if (!warehouse) return null;
  const patients = warehouse.scalar("SELECT COUNT(DISTINCT patient_id) FROM patients");
  const sites = warehouse.scalar("SELECT COUNT(DISTINCT site_id) FROM patients");
  const aes = warehouse.scalar("SELECT COUNT(*) FROM adverse_events");
  const deaths = warehouse.scalar(
    "SELECT COUNT(*) FROM (SELECT patient_id, MAX(os_event) AS e FROM patients GROUP BY patient_id) WHERE e = 1",
  );
  const arms = warehouse.query(
    "SELECT treatment_arm, COUNT(*) AS n FROM (SELECT patient_id, treatment_arm FROM patients GROUP BY patient_id) GROUP BY treatment_arm",
  );

  return (
    <aside className="space-y-3 lg:sticky lg:top-20 lg:self-start">
      <Panel title="Study snapshot" subtitle="Live from the loaded warehouse" bodyClassName="p-3">
        <div className="grid grid-cols-2 gap-2">
          <Stat label="Patients" value={String(patients)} />
          <Stat label="Sites" value={String(sites)} />
          <Stat label="AE records" value={String(aes)} />
          <Stat label="Deaths" value={String(deaths)} />
        </div>
        <dl className="mt-3 space-y-1.5 border-t border-border pt-3">
          {arms.rows.map((r) => (
            <div
              key={String(r["treatment_arm"])}
              className="flex items-center justify-between text-[12px]"
            >
              <dt className="text-muted-foreground">{String(r["treatment_arm"])}</dt>
              <dd className="font-medium tnum">{String(r["n"])} patients</dd>
            </div>
          ))}
        </dl>
      </Panel>

      <Panel title="Agent tools" bodyClassName="p-3">
        <ul className="space-y-2.5 text-[12px] leading-relaxed">
          <li>
            <span className="font-semibold">SQL Query</span>
            <span className="block text-muted-foreground">
              Read-only SELECT over five warehouse tables.
            </span>
          </li>
          <li>
            <span className="font-semibold">Documentation RAG</span>
            <span className="block text-muted-foreground">
              Section-level retrieval from the Protocol, SAP, Data Dictionary and AE Definitions.
            </span>
          </li>
          <li>
            <span className="font-semibold">Survival Analysis</span>
            <span className="block text-muted-foreground">
              Kaplan-Meier with Greenwood limits and a log-rank test — never an average that ignores
              censoring.
            </span>
          </li>
          <li>
            <span className="font-semibold">Data Quality</span>
            <span className="block text-muted-foreground">
              Seven deterministic, auditable checks — no model involvement.
            </span>
          </li>
        </ul>
      </Panel>
    </aside>
  );
}
