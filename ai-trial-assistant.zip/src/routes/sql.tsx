import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Download, Play, Save, Table2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useWarehouse } from "@/components/warehouse-provider";
import { DataGrid } from "@/components/data-grid";
import { LoadingWarehouse, PageHeader, Panel } from "@/components/primitives";
import { PlainNote } from "@/components/plain-english";
import { QueryHelper } from "@/components/query-helper";
import { explainSql, PAGE_PLAIN } from "@/lib/plain";
import { TABLES, toCsv, type QueryResult } from "@/lib/warehouse";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sql")({
  head: () => ({
    meta: [
      { title: "SQL Workbench — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Run read-only SQL against the ONC-501-301 warehouse in the browser: schema browser, saved queries, result grid and CSV export.",
      },
      { property: "og:title", content: "SQL Workbench — TrialAssist" },
      {
        property: "og:description",
        content:
          "Query patients, visits, adverse events, labs and biomarkers directly with SQLite in the browser.",
      },
    ],
  }),
  component: SqlPage,
});

const SAVED_QUERIES: { name: string; sql: string }[] = [
  {
    name: "Enrollment by arm",
    sql: `SELECT treatment_arm, COUNT(*) AS n_patients
FROM (SELECT patient_id, treatment_arm FROM patients GROUP BY patient_id)
GROUP BY treatment_arm`,
  },
  {
    name: "Discontinuation reasons",
    sql: `SELECT discontinuation_reason, COUNT(DISTINCT patient_id) AS n_patients
FROM patients
GROUP BY discontinuation_reason
ORDER BY n_patients DESC`,
  },
  {
    name: "Grade 3+ AEs by system organ class",
    sql: `SELECT soc, COUNT(*) AS n_events, COUNT(DISTINCT patient_id) AS n_patients
FROM adverse_events
WHERE grade >= 3
GROUP BY soc
ORDER BY n_events DESC`,
  },
  {
    name: "Missing PD-L1 by site",
    sql: `SELECT p.site_name, COUNT(*) AS n_patients,
       SUM(CASE WHEN b.pd_l1_status IS NULL OR b.pd_l1_status = '' THEN 1 ELSE 0 END) AS n_missing,
       ROUND(100.0 * SUM(CASE WHEN b.pd_l1_status IS NULL OR b.pd_l1_status = '' THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_missing
FROM patients p
LEFT JOIN biomarkers b ON b.patient_id = p.patient_id
GROUP BY p.site_name
ORDER BY pct_missing DESC`,
  },
  {
    name: "Demographics by arm",
    sql: `WITH u AS (SELECT patient_id, treatment_arm, age, sex, ecog_status FROM patients GROUP BY patient_id)
SELECT treatment_arm, COUNT(*) AS n, ROUND(AVG(age), 1) AS mean_age,
       SUM(CASE WHEN sex = 'Female' THEN 1 ELSE 0 END) AS n_female,
       ROUND(AVG(ecog_status), 2) AS mean_ecog
FROM u GROUP BY treatment_arm`,
  },
  {
    name: "Best tumour response (SOD change)",
    sql: `SELECT v.patient_id,
       MIN(v.tumor_sod_mm) AS nadir_sod,
       MAX(v.baseline_sod_mm) AS baseline_sod,
       ROUND(100.0 * (MIN(v.tumor_sod_mm) - MAX(v.baseline_sod_mm)) / MAX(v.baseline_sod_mm), 1) AS pct_change
FROM visits v
WHERE v.tumor_sod_mm IS NOT NULL
GROUP BY v.patient_id
ORDER BY pct_change
LIMIT 50`,
  },
  {
    name: "Out-of-range lab results",
    sql: `SELECT test_name, COUNT(*) AS n_results,
       SUM(CASE WHEN result_value < ref_low OR result_value > ref_high THEN 1 ELSE 0 END) AS n_out_of_range
FROM labs
GROUP BY test_name
ORDER BY n_out_of_range DESC`,
  },
];

const MY_QUERIES_KEY = "trialassist.sql.myQueries";

function loadMyQueries(): { name: string; sql: string }[] {
  try {
    const raw = localStorage.getItem(MY_QUERIES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed)
      ? parsed.filter((q) => q && typeof q.name === "string" && typeof q.sql === "string")
      : [];
  } catch {
    return [];
  }
}

function SqlPage() {
  const { warehouse, loading } = useWarehouse();
  const [sql, setSql] = useState(SAVED_QUERIES[0]!.sql);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [runCount, setRunCount] = useState(0);
  const [myQueries, setMyQueries] = useState<{ name: string; sql: string }[]>(() =>
    loadMyQueries(),
  );
  const resultsRef = useRef<HTMLDivElement | null>(null);

  const isSaved = [...SAVED_QUERIES, ...myQueries].some((q) => q.sql.trim() === sql.trim());

  function persist(queries: { name: string; sql: string }[]) {
    setMyQueries(queries);
    try {
      localStorage.setItem(MY_QUERIES_KEY, JSON.stringify(queries));
    } catch {
      // storage unavailable — keep in-memory copy only
    }
  }

  function saveAsNew(query = sql) {
    const trimmed = query.trim();
    if (!trimmed) return;
    if ([...SAVED_QUERIES, ...myQueries].some((q) => q.sql.trim() === trimmed)) return;
    const firstLine =
      trimmed
        .split("\n")
        .map((l) => l.trim())
        .find(Boolean) ?? "Query";
    const label = firstLine.length > 32 ? `${firstLine.slice(0, 32)}…` : firstLine;
    persist([...myQueries, { name: `My query ${myQueries.length + 1} — ${label}`, sql: trimmed }]);
  }

  function removeMyQuery(index: number) {
    persist(myQueries.filter((_, i) => i !== index));
    toast.success("Query removed");
  }

  function run(query = sql) {
    if (!warehouse) {
      toast.error("The warehouse is still loading — try again in a moment.");
      return;
    }
    const start = performance.now();
    try {
      const r = warehouse.query(query);
      setResult(r);
      setError(null);
      setElapsed(Math.round(performance.now() - start));
      setRunCount((n) => n + 1);
      saveAsNew(query);
      toast.success(`${r.rowCount} row${r.rowCount === 1 ? "" : "s"} returned`);
      requestAnimationFrame(() =>
        resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }),
      );
    } catch (e) {
      setError((e as Error).message);
      setResult(null);
      toast.error((e as Error).message);
    }
  }

  useEffect(() => {
    if (warehouse && !result && !error) run(SAVED_QUERIES[0]!.sql);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouse]);

  function exportCsv() {
    if (!result) return;
    const blob = new Blob([toCsv(result.columns, result.rows)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "trialassist-query.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${result.rows.length} rows`);
  }

  if (loading) return <LoadingWarehouse />;

  return (
    <div>
      <PageHeader
        title="SQL Workbench"
        description="Read-only SQL over the ONC-501-301 warehouse, executed by SQLite compiled to WebAssembly. Only SELECT and WITH … SELECT statements are permitted, and results are capped at 500 rows."
      />

      <PlainNote
        className="mb-5"
        title={PAGE_PLAIN["sql"]!.title}
        lines={PAGE_PLAIN["sql"]!.lines}
      />

      <div className="grid gap-5 lg:grid-cols-[260px_minmax(0,1fr)]">
        <div className="space-y-3">
          <Panel title="Schema" bodyClassName="p-0">
            <div className="max-h-[320px] overflow-y-auto">
              {TABLES.map((t) => (
                <details key={t.name} className="border-b border-grid last:border-b-0">
                  <summary className="flex cursor-pointer items-center gap-1.5 px-3 py-2 text-[12.5px] font-medium hover:bg-surface-strong">
                    <Table2 className="h-3.5 w-3.5 text-primary" />
                    {t.name}
                    <span className="ml-auto text-[11px] text-muted-foreground tnum">
                      {t.columns.length} cols
                    </span>
                  </summary>
                  <div className="px-3 pb-2.5">
                    <p className="mb-1.5 text-[11px] leading-relaxed text-muted-foreground">
                      {t.description}
                    </p>
                    <ul className="space-y-0.5 font-mono text-[11px]">
                      {t.columns.map((c) => (
                        <li key={c.name} className="flex justify-between gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              setSql((s) => `${s}${s.endsWith(" ") ? "" : " "}${c.name}`)
                            }
                            className="text-left hover:text-primary"
                          >
                            {c.name}
                          </button>
                          <span className="text-muted-foreground">{c.type}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </details>
              ))}
            </div>
          </Panel>

          <Panel title="Saved queries" bodyClassName="p-0">
            <ul>
              {SAVED_QUERIES.map((q) => (
                <li key={q.name}>
                  <button
                    type="button"
                    onClick={() => {
                      setSql(q.sql);
                      run(q.sql);
                    }}
                    className="w-full border-b border-grid px-3 py-2 text-left text-[12.5px] transition-colors last:border-b-0 hover:bg-surface-strong hover:text-primary"
                  >
                    {q.name}
                  </button>
                </li>
              ))}
            </ul>
          </Panel>

          {myQueries.length > 0 ? (
            <Panel title="My queries" bodyClassName="p-0">
              <ul>
                {myQueries.map((q, i) => (
                  <li key={`${q.name}-${i}`} className="group relative border-b border-grid last:border-b-0">
                    <button
                      type="button"
                      onClick={() => {
                        setSql(q.sql);
                        run(q.sql);
                      }}
                      className="w-full px-3 py-2 pr-8 text-left text-[12.5px] transition-colors hover:bg-surface-strong hover:text-primary"
                    >
                      {q.name}
                    </button>
                    <button
                      type="button"
                      onClick={() => removeMyQuery(i)}
                      aria-label={`Delete ${q.name}`}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground opacity-0 transition-opacity hover:text-critical group-hover:opacity-100"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            </Panel>
          ) : null}
        </div>

        <div className="min-w-0 space-y-4">
          <QueryHelper warehouse={warehouse} onUse={(next) => setSql(next)} />

          <Panel
            title="Query editor"
            actions={
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (isSaved) {
                      toast.info("This query is already saved.");
                      return;
                    }
                    saveAsNew();
                    toast.success("Saved to My queries");
                  }}
                  disabled={isSaved}
                  className={cn(
                    "flex items-center gap-1.5 rounded-md border border-border bg-surface px-2.5 py-1.5 text-[12px] font-medium",
                    isSaved
                      ? "cursor-default text-muted-foreground opacity-60"
                      : "hover:bg-surface-strong",
                  )}
                >
                  <Save className="h-3.5 w-3.5" /> {isSaved ? "Saved" : "Save"}
                </button>
                <button
                  type="button"
                  onClick={() => run()}
                  className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-[12px] font-medium text-primary-foreground"
                >
                  <Play className="h-3.5 w-3.5" /> Run
                  <span className="opacity-70">⌘↵</span>
                </button>
              </div>
            }
            bodyClassName="p-0"
          >
            <textarea
              value={sql}
              onChange={(e) => setSql(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  run();
                }
              }}
              spellCheck={false}
              rows={10}
              className="w-full resize-y bg-surface p-3.5 font-mono text-[12.5px] leading-relaxed outline-none"
            />
          </Panel>

          {error ? (
            <div className="rounded-lg border border-critical/40 bg-critical/10 px-3.5 py-3 font-mono text-[12.5px] text-critical">
              {error}
            </div>
          ) : null}

          {result ? (
            <div ref={resultsRef} className="space-y-4">
            <PlainNote
              title="What this result is"
              lines={explainSql(sql, result.rowCount, result.columns)}
            />
            <Panel
              title="Results"
              subtitle={`${result.rowCount} row${result.rowCount === 1 ? "" : "s"}${
                result.truncated ? ` (showing first ${result.rows.length})` : ""
              } · ${elapsed} ms · run #${runCount}`}
              actions={
                <button
                  type="button"
                  onClick={exportCsv}
                  className={cn(
                    "flex items-center gap-1.5 rounded-md border border-border bg-surface px-2.5 py-1.5 text-[12px] font-medium",
                    "hover:bg-surface-strong",
                  )}
                >
                  <Download className="h-3.5 w-3.5" /> Export CSV
                </button>
              }
              bodyClassName="p-0"
            >
              <DataGrid columns={result.columns} rows={result.rows} maxHeight={520} />
            </Panel>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
