import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { PageHeader, Panel } from "@/components/primitives";
import { PlainNote } from "@/components/plain-english";
import { PAGE_PLAIN } from "@/lib/plain";
import { chunkDocument, searchDocs, STUDY_DOCS, citationFor } from "@/lib/docs";
import { cn } from "@/lib/utils";

interface DocSearch {
  doc?: string | undefined;
  q?: string | undefined;
}

export const Route = createFileRoute("/documents")({
  validateSearch: (search: Record<string, unknown>): DocSearch => ({
    doc: typeof search["doc"] === "string" ? search["doc"] : undefined,
    q: typeof search["q"] === "string" ? search["q"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Study Documentation Hub — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Browse and search the ONC-501-301 protocol, statistical analysis plan, data dictionary and adverse event definitions.",
      },
      { property: "og:title", content: "Study Documentation Hub — TrialAssist" },
      {
        property: "og:description",
        content:
          "Protocol, SAP, data dictionary and AE definitions with section outlines and full-text search.",
      },
    ],
  }),
  component: DocumentsPage,
});

function DocumentsPage() {
  const { doc: docParam, q: qParam } = Route.useSearch();
  const [activeId, setActiveId] = useState(docParam ?? STUDY_DOCS[0]!.id);
  const [query, setQuery] = useState(qParam ?? "");

  const active = STUDY_DOCS.find((d) => d.id === activeId) ?? STUDY_DOCS[0]!;
  const sections = useMemo(() => chunkDocument(active), [active]);
  const hits = useMemo(() => (query.trim().length > 1 ? searchDocs(query, 8) : []), [query]);

  return (
    <div>
      <PageHeader
        title="Study Documentation"
        description="The controlled documents that govern study ONC-501-301. Search retrieves the same section chunks the query assistant cites in its answers."
      />

      <PlainNote
        className="mb-5"
        title={PAGE_PLAIN["documents"]!.title}
        lines={PAGE_PLAIN["documents"]!.lines}
      />

      <div className="mb-5 flex items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2">
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search all four documents — e.g. progression-free survival, censoring, CTCAE grade 3"
          className="w-full bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            className="shrink-0 text-[11.5px] font-medium text-muted-foreground hover:text-foreground"
          >
            Clear
          </button>
        ) : null}
      </div>

      {hits.length ? (
        <Panel
          title={`${hits.length} matching section${hits.length === 1 ? "" : "s"}`}
          subtitle="Ranked by TF-IDF keyword overlap, the same retrieval the assistant uses"
          className="mb-5"
          bodyClassName="p-0"
        >
          <ul>
            {hits.map((hit) => (
              <li
                key={`${hit.docId}-${hit.section}`}
                className="border-b border-grid last:border-b-0"
              >
                <button
                  type="button"
                  onClick={() => {
                    setActiveId(hit.docId);
                    setQuery("");
                    requestAnimationFrame(() => {
                      document
                        .getElementById(sectionId(hit.section))
                        ?.scrollIntoView({ behavior: "smooth", block: "center" });
                    });
                  }}
                  className="w-full px-4 py-3 text-left transition-colors hover:bg-surface-strong"
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="text-[12.5px] font-semibold text-primary">
                      {citationFor(hit)}
                    </span>
                    <span className="text-[11px] text-muted-foreground tnum">
                      score {hit.score}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
                    {highlight(hit.snippet, query)}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        </Panel>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-[250px_minmax(0,1fr)]">
        <div className="space-y-3 lg:sticky lg:top-20 lg:self-start">
          <Panel title="Documents" bodyClassName="p-0">
            <ul>
              {STUDY_DOCS.map((d) => (
                <li key={d.id}>
                  <button
                    type="button"
                    onClick={() => setActiveId(d.id)}
                    className={cn(
                      "w-full border-b border-grid px-3 py-2.5 text-left transition-colors last:border-b-0",
                      d.id === activeId
                        ? "bg-accent text-accent-foreground"
                        : "hover:bg-surface-strong",
                    )}
                  >
                    <span className="block text-[12.5px] font-semibold">{d.shortTitle}</span>
                    <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">
                      {d.description}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title="Outline" bodyClassName="p-0">
            <ul className="max-h-[320px] overflow-y-auto">
              {sections
                .filter((s) => s.section !== "Preamble")
                .map((s) => (
                  <li key={s.section}>
                    <a
                      href={`#${sectionId(s.section)}`}
                      className="block border-b border-grid px-3 py-1.5 text-[12px] transition-colors last:border-b-0 hover:bg-surface-strong hover:text-primary"
                    >
                      {s.section}
                    </a>
                  </li>
                ))}
            </ul>
          </Panel>
        </div>

        <Panel title={active.title} subtitle={active.description}>
          <article className="max-w-3xl space-y-4">
            {sections.map((s) => (
              <section key={s.section} id={sectionId(s.section)} className="scroll-mt-24">
                {s.section !== "Preamble" ? (
                  <h3 className="mb-1.5 text-[14px] font-semibold tracking-tight">{s.section}</h3>
                ) : null}
                <MarkdownBlock text={s.text} />
              </section>
            ))}
          </article>
        </Panel>
      </div>
    </div>
  );
}

function sectionId(section: string) {
  return `sec-${section
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")}`;
}

/** Minimal markdown rendering for the study documents: paragraphs, bullets, tables, bold. */
function MarkdownBlock({ text }: { text: string }) {
  const blocks = text.split(/\n{2,}/).filter((b) => b.trim());
  return (
    <div className="space-y-3">
      {blocks.map((block, i) => {
        const lines = block.split("\n");
        if (lines[0]?.trim().startsWith("|")) {
          const rows = lines.filter(
            (l) => l.trim().startsWith("|") && !/^\|[\s|:-]+\|$/.test(l.trim()),
          );
          const cells = rows.map((r) =>
            r
              .trim()
              .replace(/^\||\|$/g, "")
              .split("|")
              .map((c) => c.trim()),
          );
          const [header, ...body] = cells;
          return (
            <div key={i} className="overflow-x-auto">
              <table className="data-table">
                <thead>
                  <tr>
                    {header?.map((h, j) => (
                      <th key={j}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {body.map((row, j) => (
                    <tr key={j}>
                      {row.map((c, k) => (
                        <td key={k} className="whitespace-normal">
                          {inline(c)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        if (lines.every((l) => /^\s*[-*]\s/.test(l) || /^\s{2,}\S/.test(l))) {
          const items: string[] = [];
          for (const line of lines) {
            if (/^\s*[-*]\s/.test(line)) items.push(line.replace(/^\s*[-*]\s/, ""));
            else if (items.length) items[items.length - 1] += ` ${line.trim()}`;
          }
          return (
            <ul key={i} className="list-disc space-y-1 pl-5 text-[13px] leading-relaxed">
              {items.map((item, j) => (
                <li key={j}>{inline(item)}</li>
              ))}
            </ul>
          );
        }
        return (
          <p key={i} className="text-[13px] leading-relaxed">
            {inline(block.replace(/\n/g, " "))}
          </p>
        );
      })}
    </div>
  );
}

function inline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={i} className="rounded bg-surface-strong px-1 py-0.5 font-mono text-[11.5px]">
          {part.slice(1, -1)}
        </code>
      );
    }
    return <span key={i}>{part}</span>;
  });
}

function highlight(text: string, query: string) {
  const terms = query
    .toLowerCase()
    .split(/\s+/)
    .filter((t) => t.length > 2);
  if (!terms.length) return text;
  const regex = new RegExp(`(${terms.map(escapeRegex).join("|")})`, "gi");
  return text.split(regex).map((part, i) =>
    terms.includes(part.toLowerCase()) ? (
      <mark key={i} className="rounded bg-accent px-0.5 text-accent-foreground">
        {part}
      </mark>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
