import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Check, ExternalLink, KeyRound, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { PageHeader, Panel } from "@/components/primitives";
import { PlainNote } from "@/components/plain-english";
import { PAGE_PLAIN } from "@/lib/plain";
import { DEFAULT_GROQ_MODEL, readSettings, writeSettings } from "@/lib/settings";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Assistant Settings — TrialAssist ONC-501-301" },
      {
        name: "description",
        content:
          "Configure the TrialAssist query assistant: use the built-in offline orchestrator or connect a Groq API key for model-driven tool selection.",
      },
      { property: "og:title", content: "Assistant Settings — TrialAssist" },
      {
        property: "og:description",
        content: "Choose between the built-in orchestrator and a Groq-backed agent loop.",
      },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const [apiKey, setApiKey] = useState("");
  const [model, setModel] = useState(DEFAULT_GROQ_MODEL);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const s = readSettings();
    setApiKey(s.apiKey);
    setModel(s.model);
    setSaved(Boolean(s.apiKey));
  }, []);

  function save() {
    writeSettings({ apiKey: apiKey.trim(), model: model.trim() || DEFAULT_GROQ_MODEL });
    setSaved(Boolean(apiKey.trim()));
    toast.success(apiKey.trim() ? "Groq key saved in this browser" : "Settings saved");
  }

  function clear() {
    setApiKey("");
    writeSettings({ apiKey: "", model });
    setSaved(false);
    toast.success("Groq key removed — the built-in orchestrator will be used");
  }

  return (
    <div className="max-w-3xl">
      <PageHeader
        title="Assistant Settings"
        description="TrialAssist answers questions out of the box with a built-in orchestrator that runs real SQL and statistics locally. Adding a Groq key lets a model choose the tools instead."
      />

      <PlainNote
        className="mb-5"
        title={PAGE_PLAIN["settings"]!.title}
        lines={PAGE_PLAIN["settings"]!.lines}
      />

      <div className="space-y-5">
        <Panel
          title="Current mode"
          subtitle={saved ? "Groq-backed agent loop" : "Built-in orchestrator (no key required)"}
        >
          <div className="flex items-start gap-3">
            <span
              className={`mt-1 h-2 w-2 shrink-0 rounded-full ${saved ? "bg-primary" : "bg-arm-control"}`}
            />
            <p className="text-[13px] leading-relaxed text-muted-foreground">
              {saved
                ? `Questions are sent to Groq (${model}), which selects among the four tools. The tools themselves still run locally against the in-browser warehouse, so every number stays grounded in the study data. If the Groq request fails, the built-in orchestrator answers instead.`
                : "A deterministic intent router matches your question to a tool, executes real SQL, Kaplan-Meier estimation, documentation retrieval, or the data quality battery, and composes a grounded answer with citations. No network call and no key required."}
            </p>
          </div>
        </Panel>

        <Panel
          title="Groq API key"
          subtitle="Stored in this browser only; never written to the server"
        >
          <div className="space-y-3">
            <label className="block">
              <span className="label-caps">API key</span>
              <div className="mt-1.5 flex items-center gap-2 rounded-md border border-input bg-surface px-3 py-2">
                <KeyRound className="h-4 w-4 shrink-0 text-muted-foreground" />
                <input
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="gsk_…"
                  autoComplete="off"
                  className="w-full bg-transparent font-mono text-[13px] outline-none placeholder:text-muted-foreground"
                />
              </div>
            </label>

            <label className="block">
              <span className="label-caps">Model</span>
              <input
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder={DEFAULT_GROQ_MODEL}
                className="mt-1.5 w-full rounded-md border border-input bg-surface px-3 py-2 font-mono text-[13px] outline-none"
              />
              <span className="mt-1 block text-[11.5px] text-muted-foreground">
                Matches the GROQ_MODEL environment variable in the original Python project. Default:{" "}
                {DEFAULT_GROQ_MODEL}
              </span>
            </label>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={save}
                className="flex items-center gap-1.5 rounded-md bg-primary px-3.5 py-2 text-[12.5px] font-medium text-primary-foreground"
              >
                <Check className="h-3.5 w-3.5" /> Save
              </button>
              {saved ? (
                <button
                  type="button"
                  onClick={clear}
                  className="flex items-center gap-1.5 rounded-md border border-border bg-surface px-3.5 py-2 text-[12.5px] font-medium hover:bg-surface-strong"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Remove key
                </button>
              ) : null}
              <a
                href="https://console.groq.com/keys"
                target="_blank"
                rel="noreferrer"
                className="ml-auto flex items-center gap-1 text-[12px] font-medium text-primary underline-offset-2 hover:underline"
              >
                Get a Groq key <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        </Panel>

        <Panel
          title="How the agent is wired"
          subtitle="Same architecture as the source Python project"
        >
          <ul className="space-y-2.5 text-[13px] leading-relaxed">
            <li>
              <strong>sql_query</strong> — validated read-only SELECT against the five warehouse
              tables, executed by SQLite in WebAssembly.
            </li>
            <li>
              <strong>search_documentation</strong> — section-chunked TF-IDF retrieval over the
              Protocol, SAP, Data Dictionary and AE Definitions, returning citations.
            </li>
            <li>
              <strong>run_survival_analysis</strong> — Kaplan-Meier with Greenwood variance and a
              log-rank test, ported from{" "}
              <code className="font-mono text-[12px]">stats_agent.py</code>.
            </li>
            <li>
              <strong>data_quality_check</strong> — the seven deterministic checks from{" "}
              <code className="font-mono text-[12px]">data_quality_agent.py</code>; rule-based and
              reproducible, never model-generated.
            </li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}
