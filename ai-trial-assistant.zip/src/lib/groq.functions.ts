import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Single-turn proxy to Groq's OpenAI-compatible chat-completions API.
 * The agent loop itself runs in the browser, because the tools execute
 * against the in-browser SQLite warehouse. This function only carries one
 * model turn so the request shape and error handling stay server-side.
 */

const MessageSchema = z.object({
  role: z.enum(["system", "user", "assistant", "tool"]),
  content: z.string().nullable().optional(),
  tool_call_id: z.string().optional(),
  tool_calls: z
    .array(
      z.object({
        id: z.string(),
        type: z.literal("function"),
        function: z.object({ name: z.string(), arguments: z.string() }),
      }),
    )
    .optional(),
});

const InputSchema = z.object({
  apiKey: z.string().min(10),
  model: z.string().min(1),
  messages: z.array(MessageSchema).min(1),
  tools: z.array(z.record(z.string(), z.unknown())),
});

export interface GroqToolCall {
  id: string;
  name: string;
  arguments: string;
}

export interface GroqTurn {
  ok: boolean;
  content: string;
  toolCalls: GroqToolCall[];
  error?: string;
}

export const groqTurn = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data }): Promise<GroqTurn> => {
    try {
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${data.apiKey}`,
        },
        body: JSON.stringify({
          model: data.model,
          messages: data.messages,
          tools: data.tools,
          tool_choice: "auto",
          temperature: 0.1,
        }),
      });

      if (!response.ok) {
        const body = await response.text();
        let message = `Groq returned ${response.status}`;
        try {
          const parsed = JSON.parse(body) as { error?: { message?: string } };
          if (parsed.error?.message) message = parsed.error.message;
        } catch {
          if (body) message = `${message}: ${body.slice(0, 300)}`;
        }
        return { ok: false, content: "", toolCalls: [], error: message };
      }

      const json = (await response.json()) as {
        choices?: {
          message?: {
            content?: string | null;
            tool_calls?: { id: string; function: { name: string; arguments: string } }[];
          };
        }[];
      };
      const message = json.choices?.[0]?.message;
      return {
        ok: true,
        content: message?.content ?? "",
        toolCalls: (message?.tool_calls ?? []).map((c) => ({
          id: c.id,
          name: c.function.name,
          arguments: c.function.arguments,
        })),
      };
    } catch (error) {
      return {
        ok: false,
        content: "",
        toolCalls: [],
        error: `Could not reach Groq: ${(error as Error).message}`,
      };
    }
  });
