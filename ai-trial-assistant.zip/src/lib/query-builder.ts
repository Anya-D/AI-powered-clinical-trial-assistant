import { TABLES, type TableSpec } from "./warehouse";
import { answerOffline } from "./orchestrator";
import type { Warehouse } from "./warehouse";

/* ------------------------------------------------------------------ *
 * Point-and-click builder: turns plain choices into valid SQL.
 * ------------------------------------------------------------------ */

export type FilterOp =
  | "equals"
  | "not_equals"
  | "contains"
  | "greater_than"
  | "less_than"
  | "is_empty"
  | "is_not_empty";

export const FILTER_OPS: { value: FilterOp; label: string; needsValue: boolean }[] = [
  { value: "equals", label: "is exactly", needsValue: true },
  { value: "not_equals", label: "is not", needsValue: true },
  { value: "contains", label: "contains", needsValue: true },
  { value: "greater_than", label: "is greater than", needsValue: true },
  { value: "less_than", label: "is less than", needsValue: true },
  { value: "is_empty", label: "is blank", needsValue: false },
  { value: "is_not_empty", label: "is filled in", needsValue: false },
];

export type BuilderMode =
  | "rows"
  | "count_rows"
  | "count_patients"
  | "average"
  | "sum"
  | "min_max";

export const BUILDER_MODES: { value: BuilderMode; label: string; needsNumeric: boolean }[] = [
  { value: "rows", label: "Show the matching records", needsNumeric: false },
  { value: "count_rows", label: "Count the matching records", needsNumeric: false },
  { value: "count_patients", label: "Count the distinct patients", needsNumeric: false },
  { value: "average", label: "Average of a number column", needsNumeric: true },
  { value: "sum", label: "Total (sum) of a number column", needsNumeric: true },
  { value: "min_max", label: "Lowest and highest of a number column", needsNumeric: true },
];

export interface BuilderFilter {
  column: string;
  op: FilterOp;
  value: string;
}

export interface BuilderSpec {
  table: string;
  mode: BuilderMode;
  measureColumn: string;
  groupBy: string;
  filters: BuilderFilter[];
  limit: number;
}

export const DEFAULT_SPEC: BuilderSpec = {
  table: "patients",
  mode: "count_patients",
  measureColumn: "",
  groupBy: "treatment_arm",
  filters: [],
  limit: 100,
};

export function tableSpec(name: string): TableSpec {
  return TABLES.find((t) => t.name === name) ?? TABLES[0]!;
}

export function numericColumns(name: string): string[] {
  return tableSpec(name)
    .columns.filter((c) => c.type === "INTEGER" || c.type === "REAL")
    .map((c) => c.name);
}

const quote = (v: string) => `'${v.replace(/'/g, "''")}'`;

function filterSql(f: BuilderFilter): string | null {
  const col = f.column;
  if (!col) return null;
  const v = f.value.trim();
  switch (f.op) {
    case "is_empty":
      return `(${col} IS NULL OR TRIM(${col}) = '')`;
    case "is_not_empty":
      return `(${col} IS NOT NULL AND TRIM(${col}) <> '')`;
    case "contains":
      return v ? `${col} LIKE ${quote(`%${v}%`)}` : null;
    case "greater_than":
      return v ? `CAST(${col} AS REAL) > ${Number(v) || 0}` : null;
    case "less_than":
      return v ? `CAST(${col} AS REAL) < ${Number(v) || 0}` : null;
    case "not_equals":
      return v ? `${col} <> ${quote(v)}` : null;
    case "equals":
    default:
      return v ? `${col} = ${quote(v)}` : null;
  }
}

/** Build a read-only SELECT statement from the point-and-click choices. */
export function buildSql(spec: BuilderSpec): string {
  const t = tableSpec(spec.table);
  const isPatients = t.name === "patients";
  const where = spec.filters.map(filterSql).filter(Boolean) as string[];
  const whereSql = where.length ? `\nWHERE ${where.join("\n  AND ")}` : "";
  const group = spec.groupBy.trim();
  const measure = spec.measureColumn.trim();

  // The patients table contains duplicate rows, so patient-level counts
  // always de-duplicate on patient_id.
  let expr: string;
  let alias: string;
  switch (spec.mode) {
    case "count_rows":
      expr = "COUNT(*)";
      alias = "n_records";
      break;
    case "count_patients":
      expr = "COUNT(DISTINCT patient_id)";
      alias = "n_patients";
      break;
    case "average":
      expr = measure ? `ROUND(AVG(CAST(${measure} AS REAL)), 2)` : "COUNT(*)";
      alias = measure ? `avg_${measure}` : "n_records";
      break;
    case "sum":
      expr = measure ? `ROUND(SUM(CAST(${measure} AS REAL)), 2)` : "COUNT(*)";
      alias = measure ? `total_${measure}` : "n_records";
      break;
    case "min_max":
      expr = measure
        ? `MIN(CAST(${measure} AS REAL)) AS lowest_${measure},\n       MAX(CAST(${measure} AS REAL)) AS highest_${measure}`
        : "COUNT(*)";
      alias = "";
      break;
    case "rows":
    default: {
      const base = isPatients
        ? `SELECT DISTINCT ${t.columns
            .slice(0, 8)
            .map((c) => c.name)
            .join(", ")}\nFROM patients${whereSql}\nORDER BY patient_id\nLIMIT ${spec.limit};`
        : `SELECT *\nFROM ${t.name}${whereSql}\nLIMIT ${spec.limit};`;
      return base;
    }
  }

  const select = alias ? `${expr} AS ${alias}` : expr;

  if (group) {
    return `SELECT ${group},\n       ${select}\nFROM ${t.name}${whereSql}\nGROUP BY ${group}\nORDER BY 2 DESC;`;
  }
  return `SELECT ${select}\nFROM ${t.name}${whereSql};`;
}

/** Plain-English description of what the built query will return. */
export function describeSpec(spec: BuilderSpec): string {
  const modeLabel =
    BUILDER_MODES.find((m) => m.value === spec.mode)?.label.toLowerCase() ?? "show records";
  const filters = spec.filters
    .filter((f) => f.column)
    .map((f) => {
      const op = FILTER_OPS.find((o) => o.value === f.op);
      return `${f.column} ${op?.label ?? "is"}${op?.needsValue ? ` "${f.value}"` : ""}`;
    });
  let s = `This will ${modeLabel} in the ${spec.table} table`;
  if (spec.measureColumn && ["average", "sum", "min_max"].includes(spec.mode)) {
    s += ` using ${spec.measureColumn}`;
  }
  if (filters.length) s += `, keeping only rows where ${filters.join(" and ")}`;
  if (spec.groupBy && spec.mode !== "rows") s += `, broken down by ${spec.groupBy}`;
  return `${s}.`;
}

/* ------------------------------------------------------------------ *
 * Plain-English question -> SQL, reusing the built-in orchestrator.
 * ------------------------------------------------------------------ */

export interface SqlSuggestion {
  sql: string;
  explanation: string;
  rowCount?: number;
}

/**
 * Runs the built-in orchestrator over a natural-language question and returns
 * the SQL it wrote, if the question resolved to a database query.
 */
export function suggestSql(wh: Warehouse, question: string): SqlSuggestion | null {
  const answer = answerOffline(wh, question);
  const step = answer.trace.find((s) => s.tool === "sql_query" && s.sql);
  if (!step?.sql) return null;
  const sql = step.sql.trim();
  return {
    sql: sql.endsWith(";") ? sql : `${sql};`,
    explanation: step.rationale,
    ...(step.result.rowCount != null ? { rowCount: step.result.rowCount } : {}),
  };
}

export const BUILDER_EXAMPLES = [
  "How many patients are in each treatment arm?",
  "Show me patients who discontinued treatment due to toxicity",
  "Which sites have the most missing biomarker measurements?",
  "How many Grade 3 or higher adverse events were reported?",
  "What is the median age of enrolled patients?",
  "Break down discontinuation reasons",
];
