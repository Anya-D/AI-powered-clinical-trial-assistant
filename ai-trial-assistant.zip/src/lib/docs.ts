/**
 * Study documentation corpus + section-level retrieval, ported from rag_agent.py.
 * Documents are chunked by markdown heading and scored with TF-IDF style
 * keyword overlap so every answer can cite a document and section.
 */
import protocolMd from "../content/protocol.md?raw";
import sapMd from "../content/statistical_analysis_plan.md?raw";
import dictionaryMd from "../content/data_dictionary.md?raw";
import aeMd from "../content/ae_definitions.md?raw";

export interface StudyDoc {
  id: string;
  title: string;
  shortTitle: string;
  description: string;
  markdown: string;
}

export const STUDY_DOCS: StudyDoc[] = [
  {
    id: "protocol",
    title: "Protocol ONC-501 (Synopsis)",
    shortTitle: "Protocol",
    description: "Study design, endpoints, population, visit schema, discontinuation rules.",
    markdown: protocolMd,
  },
  {
    id: "sap",
    title: "Statistical Analysis Plan (Synopsis)",
    shortTitle: "SAP",
    description: "Analysis populations, OS/PFS methodology, ORR, safety, missing data.",
    markdown: sapMd,
  },
  {
    id: "data_dictionary",
    title: "Data Dictionary",
    shortTitle: "Data Dictionary",
    description: "Field-by-field definitions for all five warehouse tables.",
    markdown: dictionaryMd,
  },
  {
    id: "ae_definitions",
    title: "Adverse Event Definitions and Grading Conventions",
    shortTitle: "AE Definitions",
    description: "AE/SAE definitions, CTCAE v5.0 grading, causality, AESIs.",
    markdown: aeMd,
  },
];

export interface DocChunk {
  docId: string;
  docTitle: string;
  shortTitle: string;
  section: string;
  text: string;
  /** The document's own title block — front matter, not substantive content. */
  isTitleBlock: boolean;
}

export function chunkDocument(doc: StudyDoc): DocChunk[] {
  const lines = doc.markdown.split("\n");
  const chunks: DocChunk[] = [];
  let section = "Preamble";
  let level = 1;
  let buffer: string[] = [];

  const flush = () => {
    const text = buffer.join("\n").trim();
    if (text) {
      chunks.push({
        docId: doc.id,
        docTitle: doc.title,
        shortTitle: doc.shortTitle,
        section,
        text,
        isTitleBlock: level <= 1,
      });
    }
    buffer = [];
  };

  for (const line of lines) {
    const heading = /^(#{1,3})\s+(.*)$/.exec(line);
    if (heading) {
      flush();
      level = heading[1]!.length;
      section = heading[2]!.trim();
    } else {
      buffer.push(line);
    }
  }
  flush();
  return chunks;
}

export const DOC_CHUNKS: DocChunk[] = STUDY_DOCS.flatMap(chunkDocument);

const STOPWORDS = new Set([
  "the",
  "a",
  "an",
  "of",
  "and",
  "or",
  "to",
  "in",
  "is",
  "are",
  "for",
  "on",
  "by",
  "with",
  "how",
  "what",
  "which",
  "that",
  "this",
  "be",
  "was",
  "were",
  "as",
  "at",
  "from",
  "per",
  "it",
  "do",
  "does",
  "did",
  "me",
  "my",
  "we",
  "you",
  "i",
  "show",
  "many",
  "much",
]);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[^a-z0-9-]+/)
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

const DF = (() => {
  const df = new Map<string, number>();
  for (const chunk of DOC_CHUNKS) {
    for (const term of new Set(tokenize(`${chunk.section} ${chunk.text}`))) {
      df.set(term, (df.get(term) ?? 0) + 1);
    }
  }
  return df;
})();

export interface DocHit extends DocChunk {
  score: number;
  snippet: string;
}

export function searchDocs(query: string, topK = 3): DocHit[] {
  const terms = tokenize(query);
  if (terms.length === 0) return [];
  const N = DOC_CHUNKS.length;

  const scored = DOC_CHUNKS.map((chunk) => {
    const body = `${chunk.section} ${chunk.text}`.toLowerCase();
    const bodyTerms = tokenize(body);
    const counts = new Map<string, number>();
    for (const t of bodyTerms) counts.set(t, (counts.get(t) ?? 0) + 1);

    let score = 0;
    let matched = 0;
    for (const term of terms) {
      const tf = counts.get(term) ?? 0;
      if (!tf) continue;
      matched++;
      const idf = Math.log((N + 1) / ((DF.get(term) ?? 0) + 1)) + 1;
      score += (tf / bodyTerms.length) * idf * 100;
      if (chunk.section.toLowerCase().includes(term)) score += 3;
    }
    // Reward passages that cover more of the question's distinct terms, so a
    // short passage matching one common word can't outrank the real answer.
    score *= 0.4 + 0.6 * (matched / terms.length);
    // A document's title block is front matter (sponsor, version, full title).
    // It matches words like "protocol" strongly but never answers a question.
    if (chunk.isTitleBlock) score *= 0.2;
    return {
      ...chunk,
      score: Math.round(score * 100) / 100,
      snippet: snippetFor(chunk.text, terms),
    };
  });

  return scored
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

function snippetFor(text: string, terms: string[]): string {
  const flat = text.replace(/\s+/g, " ").trim();
  const lower = flat.toLowerCase();
  let idx = -1;
  for (const t of terms) {
    const i = lower.indexOf(t);
    if (i >= 0 && (idx === -1 || i < idx)) idx = i;
  }
  if (idx === -1) return flat.slice(0, 320);
  const start = Math.max(0, idx - 120);
  return (
    (start > 0 ? "…" : "") + flat.slice(start, start + 360) + (flat.length > start + 360 ? "…" : "")
  );
}

export function citationFor(hit: DocChunk): string {
  return `${hit.shortTitle} › ${hit.section}`;
}
