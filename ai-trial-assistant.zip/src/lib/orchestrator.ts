/**
 * The Clinical Query Agent.
 *
 * Built-in (offline) mode: a deterministic intent router that picks tools,
 * runs real SQL / Kaplan-Meier / data-quality routines against the loaded
 * warehouse, and composes a grounded answer with citations.
 *
 * Groq mode: the same tools are exposed to a Groq model, which chooses them
 * itself across a multi-step loop.
 */
import { runDataQuality } from "./dq";
import { citationFor, searchDocs, type DocHit } from "./docs";
import {
  daysToMonths,
  formatP,
  survivalAnalysis,
  type SurvivalAnalysis,
  type SurvivalRecord,
} from "./stats";
import { SCHEMA_DESCRIPTION, type QueryResult, type Row, type Warehouse } from "./warehouse";

export type ToolName =
  "sql_query" | "search_documentation" | "run_survival_analysis" | "data_quality_check";

export const TOOL_LABELS: Record<ToolName, string> = {
  sql_query: "SQL Query",
  search_documentation: "Documentation RAG",
  run_survival_analysis: "Survival Analysis",
  data_quality_check: "Data Quality",
};

export interface TraceStep {
  index: number;
  tool: ToolName;
  rationale: string;
  input: Record<string, unknown>;
  sql?: string;
  result: {
    summary: string;
    columns?: string[];
    rows?: Row[];
    rowCount?: number;
    truncated?: boolean;
    hits?: DocHit[];
    survival?: SurvivalAnalysis;
    metrics?: { label: string; value: string }[];
    error?: string;
  };
  durationMs: number;
}

export interface Citation {
  document: string;
  section: string;
  docId: string;
}

export interface AgentAnswer {
  question: string;
  answer: string;
  trace: TraceStep[];
  citations: Citation[];
  mode: "builtin" | "groq";
  model?: string;
}

export const SAMPLE_QUESTIONS = [
  "How many patients discontinued treatment?",
  "How much longer did patients on ONC-501 survive vs. standard of care?",
  "How is progression-free survival defined, per the protocol?",
  "Which sites have the highest percentage of missing biomarker measurements?",
  "Show me patients who discontinued treatment due to toxicity.",
  "How many Grade 3+ adverse events occurred?",
  "What is the median age of patients in the treatment arm?",
  "Run the full data quality report.",
];

/* ------------------------------------------------------------------ tools */

export function toolSqlQuery(
  wh: Warehouse,
  query: string,
  rationale: string,
  index: number,
): TraceStep {
  const start = performance.now();
  try {
    const result: QueryResult = wh.query(query);
    return {
      index,
      tool: "sql_query",
      rationale,
      input: { query },
      sql: query,
      result: {
        summary: `${result.rowCount} row${result.rowCount === 1 ? "" : "s"} returned`,
        columns: result.columns,
        rows: result.rows,
        rowCount: result.rowCount,
        truncated: result.truncated,
      },
      durationMs: Math.round(performance.now() - start),
    };
  } catch (error) {
    return {
      index,
      tool: "sql_query",
      rationale,
      input: { query },
      sql: query,
      result: { summary: "Query failed", error: (error as Error).message },
      durationMs: Math.round(performance.now() - start),
    };
  }
}

export function toolSearchDocs(
  query: string,
  rationale: string,
  index: number,
  topK = 3,
): TraceStep {
  const start = performance.now();
  const hits = searchDocs(query, topK);
  return {
    index,
    tool: "search_documentation",
    rationale,
    input: { query, top_k: topK },
    result: {
      summary: hits.length
        ? `${hits.length} passage${hits.length === 1 ? "" : "s"} retrieved: ${hits.map(citationFor).join(", ")}`
        : "No matching passage found",
      hits,
    },
    durationMs: Math.round(performance.now() - start),
  };
}

export function loadSurvivalRecords(wh: Warehouse, endpoint: "os" | "pfs"): SurvivalRecord[] {
  const result = wh.query(
    `SELECT patient_id, treatment_arm, ${endpoint}_time_days AS t, ${endpoint}_event AS e
     FROM patients
     WHERE treatment_arm IN ('ONC-501','Standard of Care')
       AND ${endpoint}_time_days IS NOT NULL
     GROUP BY patient_id`,
    2000,
  );
  return result.rows.map((r) => ({
    time: Number(r["t"]),
    event: Number(r["e"]),
    group: String(r["treatment_arm"]),
  }));
}

export function toolSurvival(
  wh: Warehouse,
  endpoint: "os" | "pfs",
  rationale: string,
  index: number,
): TraceStep {
  const start = performance.now();
  const analysis = survivalAnalysis(loadSurvivalRecords(wh, endpoint), endpoint);
  const [treat, control] = analysis.curves;
  const metrics = [
    {
      label: `Median ${endpoint.toUpperCase()} — ONC-501`,
      value:
        treat?.median != null
          ? `${treat.median} d (${daysToMonths(treat.median).toFixed(1)} mo)`
          : "Not reached",
    },
    {
      label: `Median ${endpoint.toUpperCase()} — Standard of Care`,
      value:
        control?.median != null
          ? `${control.median} d (${daysToMonths(control.median).toFixed(1)} mo)`
          : "Not reached",
    },
    {
      label: "Median difference",
      value:
        analysis.medianDifferenceDays != null
          ? `${analysis.medianDifferenceDays > 0 ? "+" : ""}${analysis.medianDifferenceDays} d (${daysToMonths(analysis.medianDifferenceDays).toFixed(1)} mo)`
          : "Not estimable",
    },
    { label: "Log-rank χ²", value: analysis.logrank.chi2.toFixed(3) },
    { label: "Log-rank p-value", value: formatP(analysis.logrank.pValue) },
    {
      label: "Hazard ratio (ONC-501 vs SoC)",
      value: analysis.logrank.hazardRatio != null ? analysis.logrank.hazardRatio.toFixed(3) : "n/a",
    },
    {
      label: "Events / N",
      value: analysis.curves.map((c) => `${c.label}: ${c.events}/${c.n}`).join("  ·  "),
    },
  ];
  return {
    index,
    tool: "run_survival_analysis",
    rationale,
    input: { endpoint },
    result: {
      summary: `Kaplan-Meier ${analysis.endpointLabel} by treatment arm, log-rank p ${formatP(analysis.logrank.pValue)}`,
      survival: analysis,
      metrics,
    },
    durationMs: Math.round(performance.now() - start),
  };
}

export function toolDataQuality(wh: Warehouse, rationale: string, index: number): TraceStep {
  const start = performance.now();
  const report = runDataQuality(wh);
  return {
    index,
    tool: "data_quality_check",
    rationale,
    input: { checks: "all" },
    result: {
      summary: `${report.findings.length} checks run · heuristic quality score ${report.qualityScore}/100`,
      metrics: report.findings.map((f) => ({
        label: `[${f.severity}] ${f.check}`,
        value: `${f.count} case(s)`,
      })),
      columns: ["site_name", "n_patients", "n_missing", "pct_missing"],
      rows: report.siteMissingness.slice(0, 12) as unknown as Row[],
    },
    durationMs: Math.round(performance.now() - start),
  };
}

/* ------------------------------------------------------- intent detection */

const has = (q: string, ...terms: string[]) => terms.some((t) => q.includes(t));

function num(step: TraceStep, key: string): number {
  const row = step.result.rows?.[0];
  if (!row) return 0;
  const value = row[key];
  return typeof value === "number" ? value : Number(value ?? 0);
}

function citationsFrom(steps: TraceStep[]): Citation[] {
  const out: Citation[] = [];
  const seen = new Set<string>();
  for (const step of steps) {
    for (const hit of step.result.hits ?? []) {
      const key = `${hit.docId}:${hit.section}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ document: hit.docTitle, section: hit.section, docId: hit.docId });
    }
  }
  return out;
}

/** Deterministic intent router — the built-in orchestrator. */
export function answerOffline(wh: Warehouse, question: string): AgentAnswer {
  const q = question.toLowerCase();
  const steps: TraceStep[] = [];
  let answer = "";
  let i = 1;

  const survivalIntent = has(
    q,
    "survive",
    "survival",
    "os ",
    "overall survival",
    "kaplan",
    "how much longer",
    "time-to-event",
    "hazard",
    "median os",
    "progression-free survival benefit",
    "live longer",
  );
  const pfsDefinition = has(q, "defined", "definition", "define") && has(q, "pfs", "progression");
  const isDefinitional = has(
    q,
    "how is",
    "defined",
    "definition",
    "per the protocol",
    "what does",
    "according to the protocol",
    "sap says",
  );

  if (pfsDefinition || (isDefinitional && !survivalIntent)) {
    const doc = toolSearchDocs(
      question,
      "Definitional question — retrieve the governing document section.",
      i++,
    );
    steps.push(doc);
    const hits = doc.result.hits ?? [];
    if (hits.length) {
      const top = hits[0]!;
      answer =
        `Per the ${top.docTitle}, section “${top.section}”:\n\n> ${top.snippet}\n\n` +
        (hits.length > 1
          ? `Related guidance appears in ${hits.slice(1).map(citationFor).join(" and ")}.`
          : "");
    } else {
      answer = "No passage in the study documentation matched that question.";
    }
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (survivalIntent) {
    const endpoint: "os" | "pfs" = has(q, "pfs", "progression") ? "pfs" : "os";
    const stats = toolSurvival(
      wh,
      endpoint,
      "Time-to-event comparison between arms — a SQL average would ignore censoring, so Kaplan-Meier with a log-rank test is required.",
      i++,
    );
    steps.push(stats);
    const doc = toolSearchDocs(
      endpoint === "os"
        ? "overall survival primary endpoint analysis method"
        : "progression-free survival analysis",
      "Ground the endpoint definition and analysis method in the SAP/protocol.",
      i++,
      2,
    );
    steps.push(doc);

    const a = stats.result.survival!;
    const [treat, control] = a.curves;
    const diff = a.medianDifferenceDays;
    const label = endpoint === "os" ? "overall survival" : "progression-free survival";
    answer =
      diff != null
        ? `Median ${label} was ${diff > 0 ? "longer" : "shorter"} on ONC-501 by ${Math.abs(diff)} days (${Math.abs(daysToMonths(diff)).toFixed(1)} months): ` +
          `${treat!.median} days (${daysToMonths(treat!.median!).toFixed(1)} mo) on ONC-501 versus ${control!.median} days (${daysToMonths(control!.median!).toFixed(1)} mo) on Standard of Care. ` +
          `The log-rank test gives χ² = ${a.logrank.chi2.toFixed(2)}, p ${formatP(a.logrank.pValue)}` +
          (a.logrank.hazardRatio != null
            ? `, hazard ratio ${a.logrank.hazardRatio.toFixed(2)}`
            : "") +
          `. Events: ${treat!.events}/${treat!.n} on ONC-501 and ${control!.events}/${control!.n} on Standard of Care; the remainder are censored.`
        : `Median ${label} was not reached in at least one arm, so a median difference is not estimable. Log-rank χ² = ${a.logrank.chi2.toFixed(2)}, p ${formatP(a.logrank.pValue)}.`;
    answer += `\n\nPer the ${doc.result.hits?.[0]?.docTitle ?? "Statistical Analysis Plan"}, this endpoint is analysed by Kaplan-Meier with a log-rank comparison of arms; censored patients contribute follow-up time up to their censoring date.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (
    has(q, "missing biomarker", "pd-l1", "pd l1", "biomarker") &&
    has(q, "site", "missing", "highest")
  ) {
    const sql = `SELECT p.site_id, p.site_name, COUNT(*) AS n_patients,
       SUM(CASE WHEN b.pd_l1_status IS NULL OR b.pd_l1_status = '' THEN 1 ELSE 0 END) AS n_missing,
       ROUND(100.0 * SUM(CASE WHEN b.pd_l1_status IS NULL OR b.pd_l1_status = '' THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_missing
FROM patients p LEFT JOIN biomarkers b ON b.patient_id = p.patient_id
GROUP BY p.site_id, p.site_name
ORDER BY pct_missing DESC`;
    const step = toolSqlQuery(
      wh,
      sql,
      "Missingness rate by site is a grouped aggregate over patients left-joined to biomarkers.",
      i++,
    );
    steps.push(step);
    const docStep = toolSearchDocs(
      "missing biomarker PD-L1 handling missing data by site",
      "Confirm how the SAP says missing PD-L1 results are handled.",
      i++,
      2,
    );
    steps.push(docStep);
    const rows = step.result.rows ?? [];
    const top = rows.slice(0, 3);
    answer =
      `The highest PD-L1 missingness is at ${top
        .map(
          (r) => `${r["site_name"]} (${r["pct_missing"]}%, ${r["n_missing"]}/${r["n_patients"]})`,
        )
        .join(", ")}. ` +
      `Across all ${rows.length} sites, ${rows.reduce((s, r) => s + Number(r["n_missing"]), 0)} of ${rows.reduce((s, r) => s + Number(r["n_patients"]), 0)} patient records have no PD-L1 status. ` +
      `Per the ${docStep.result.hits?.[0]?.docTitle ?? "Statistical Analysis Plan"}, missing PD-L1 results are summarised descriptively by site and are not imputed.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (
    has(q, "toxicity", "due to adverse", "because of adverse", "discontinued due to ae") ||
    (has(q, "discontinu") && has(q, "adverse event", "toxicity", "ae"))
  ) {
    const sql = `SELECT DISTINCT p.patient_id, p.site_name, p.treatment_arm, p.age, p.sex,
       p.discontinuation_reason, p.discontinuation_date,
       (SELECT GROUP_CONCAT(DISTINCT ae.ae_term) FROM adverse_events ae
          WHERE ae.patient_id = p.patient_id AND ae.led_to_discontinuation = 'True') AS causative_events
FROM patients p
WHERE p.discontinuation_reason = 'Adverse Event'
ORDER BY p.discontinuation_date`;
    const step = toolSqlQuery(
      wh,
      sql,
      "Toxicity-driven discontinuation is recorded as discontinuation_reason = 'Adverse Event'; join the causative AE terms.",
      i++,
    );
    steps.push(step);
    const docStep = toolSearchDocs(
      "adverse events leading to discontinuation definition",
      "Cite the AE Definitions convention for discontinuation-causing events.",
      i++,
      2,
    );
    steps.push(docStep);
    const byArm = toolSqlQuery(
      wh,
      `SELECT treatment_arm, COUNT(DISTINCT patient_id) AS n FROM patients WHERE discontinuation_reason = 'Adverse Event' GROUP BY treatment_arm`,
      "Break the toxicity discontinuations down by treatment arm.",
      i++,
    );
    steps.push(byArm);
    answer =
      `${step.result.rowCount} patient(s) discontinued study treatment for toxicity (discontinuation_reason = 'Adverse Event'), ` +
      `${(byArm.result.rows ?? []).map((r) => `${r["n"]} on ${r["treatment_arm"]}`).join(" and ")}. ` +
      `The table below lists each patient with the adverse event term(s) flagged as leading to discontinuation. ` +
      `Per the ${docStep.result.hits?.[0]?.docTitle ?? "AE Definitions"}, an event is flagged this way only when the investigator attributes permanent treatment cessation to it.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (
    has(q, "grade 3", "grade 3+", "grade three", "high grade", "severe adverse", "serious adverse")
  ) {
    const serious = has(q, "serious");
    const sql = serious
      ? `SELECT COUNT(*) AS n_events, COUNT(DISTINCT patient_id) AS n_patients FROM adverse_events WHERE serious = 'True'`
      : `SELECT COUNT(*) AS n_events, COUNT(DISTINCT patient_id) AS n_patients FROM adverse_events WHERE grade >= 3`;
    const step = toolSqlQuery(
      wh,
      sql,
      serious ? "Count serious adverse events." : "Grade 3+ means CTCAE grade >= 3.",
      i++,
    );
    steps.push(step);
    const breakdown = toolSqlQuery(
      wh,
      serious
        ? `SELECT p.treatment_arm, COUNT(*) AS n_events, COUNT(DISTINCT ae.patient_id) AS n_patients
FROM adverse_events ae JOIN (SELECT DISTINCT patient_id, treatment_arm FROM patients GROUP BY patient_id) p ON p.patient_id = ae.patient_id
WHERE ae.serious = 'True' GROUP BY p.treatment_arm`
        : `SELECT p.treatment_arm, COUNT(*) AS n_events, COUNT(DISTINCT ae.patient_id) AS n_patients
FROM adverse_events ae JOIN (SELECT DISTINCT patient_id, treatment_arm FROM patients GROUP BY patient_id) p ON p.patient_id = ae.patient_id
WHERE ae.grade >= 3 GROUP BY p.treatment_arm`,
      "Split the count by treatment arm for a safety comparison.",
      i++,
    );
    steps.push(breakdown);
    const docStep = toolSearchDocs(
      "CTCAE severity grading serious adverse event",
      "Cite the grading convention.",
      i++,
      2,
    );
    steps.push(docStep);
    answer =
      `${num(step, "n_events")} ${serious ? "serious" : "Grade 3 or higher"} adverse events were reported, affecting ${num(step, "n_patients")} patients. ` +
      `By arm: ${(breakdown.result.rows ?? []).map((r) => `${r["treatment_arm"]} — ${r["n_events"]} events in ${r["n_patients"]} patients`).join("; ")}. ` +
      `Grades follow CTCAE v5.0 as described in the AE Definitions document.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (has(q, "data quality", "discrepanc", "audit", "quality report", "quality check")) {
    const step = toolDataQuality(
      wh,
      "A data quality question routes to the deterministic rule-based checker, not the model.",
      i++,
    );
    steps.push(step);
    const report = runDataQuality(wh);
    const critical = report.findings.filter((f) => f.severity === "critical" && f.count > 0);
    answer =
      `${report.findings.length} deterministic checks ran across ${report.nPatients} patients; heuristic quality score ${report.qualityScore}/100. ` +
      (critical.length
        ? `Critical findings: ${critical.map((f) => `${f.check} (${f.count})`).join("; ")}. `
        : "No critical findings. ") +
      `See the Data Quality dashboard for affected identifiers and AE-to-discontinuation reconciliation.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (has(q, "median age", "average age", "mean age", "age of patients")) {
    const arm = has(q, "treatment arm", "onc-501", "onc 501") ? "ONC-501" : null;
    const where = arm ? ` WHERE treatment_arm = '${arm}'` : "";
    const sql = `WITH unique_patients AS (SELECT patient_id, treatment_arm, age FROM patients${where} GROUP BY patient_id)
SELECT treatment_arm, COUNT(*) AS n, ROUND(AVG(age), 1) AS mean_age,
       MIN(age) AS min_age, MAX(age) AS max_age
FROM unique_patients GROUP BY treatment_arm`;
    const step = toolSqlQuery(
      wh,
      sql,
      "Demographic aggregate; de-duplicate patient rows first because the dataset contains injected duplicates.",
      i++,
    );
    steps.push(step);
    const medianSql = `WITH unique_patients AS (SELECT patient_id, age FROM patients${where} GROUP BY patient_id),
ordered AS (SELECT age, ROW_NUMBER() OVER (ORDER BY age) AS rn, COUNT(*) OVER () AS n FROM unique_patients)
SELECT ROUND(AVG(age), 1) AS median_age FROM ordered WHERE rn IN ((n + 1) / 2, (n + 2) / 2)`;
    const medianStep = toolSqlQuery(
      wh,
      medianSql,
      "SQLite has no MEDIAN(); compute it from the ordered row numbers.",
      i++,
    );
    steps.push(medianStep);
    answer =
      `Median age${arm ? ` in the ${arm} arm` : ""} is ${num(medianStep, "median_age")} years. ` +
      (step.result.rows ?? [])
        .map(
          (r) =>
            `${r["treatment_arm"]}: n = ${r["n"]}, mean ${r["mean_age"]}, range ${r["min_age"]}–${r["max_age"]}`,
        )
        .join("; ") +
      ".";
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (has(q, "discontinu")) {
    const sql = `SELECT discontinuation_reason, COUNT(DISTINCT patient_id) AS n_patients
FROM patients
GROUP BY discontinuation_reason
ORDER BY n_patients DESC`;
    const step = toolSqlQuery(
      wh,
      sql,
      "Discontinuation status is a categorical field on patients; count distinct patients per reason.",
      i++,
    );
    steps.push(step);
    const docStep = toolSearchDocs(
      "discontinuation of study treatment reasons",
      "Cite the protocol's list of discontinuation reasons.",
      i++,
      2,
    );
    steps.push(docStep);
    const rows = step.result.rows ?? [];
    const ongoing = rows.find((r) => r["discontinuation_reason"] === "Ongoing");
    const total = rows.reduce((s, r) => s + Number(r["n_patients"]), 0);
    const discontinued = total - Number(ongoing?.["n_patients"] ?? 0);
    answer =
      `${discontinued} of ${total} patients have discontinued study treatment; ${Number(ongoing?.["n_patients"] ?? 0)} remain ongoing as of the data cutoff. ` +
      `By reason: ${rows
        .filter((r) => r["discontinuation_reason"] !== "Ongoing")
        .map((r) => `${r["discontinuation_reason"]} — ${r["n_patients"]}`)
        .join("; ")}. ` +
      `Per the ${docStep.result.hits?.[0]?.docTitle ?? "Protocol"}, patients who discontinue treatment continue to be followed for survival unless they withdraw consent.`;
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  if (
    has(
      q,
      "enroll",
      "how many patients",
      "how many sites",
      "demographic",
      "region",
      "ecog",
      "sex",
      "race",
      "count",
    )
  ) {
    const sql = `WITH unique_patients AS (SELECT patient_id, treatment_arm, region, site_id FROM patients GROUP BY patient_id)
SELECT treatment_arm, COUNT(*) AS n_patients, COUNT(DISTINCT site_id) AS n_sites, COUNT(DISTINCT region) AS n_regions
FROM unique_patients GROUP BY treatment_arm`;
    const step = toolSqlQuery(
      wh,
      sql,
      "Enrollment overview by arm, de-duplicated on patient_id.",
      i++,
    );
    steps.push(step);
    const rows = step.result.rows ?? [];
    answer =
      `${rows.reduce((s, r) => s + Number(r["n_patients"]), 0)} unique patients are enrolled across ${wh.scalar("SELECT COUNT(DISTINCT site_id) FROM patients")} sites in ${wh.scalar("SELECT COUNT(DISTINCT region) FROM patients")} regions. ` +
      rows.map((r) => `${r["treatment_arm"]}: ${r["n_patients"]}`).join("; ") +
      ".";
    return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
  }

  // Fallback: documentation retrieval plus a schema-grounded nudge.
  const doc = toolSearchDocs(
    question,
    "No structured intent matched with confidence — search the study documentation first.",
    i++,
  );
  steps.push(doc);
  const hits = doc.result.hits ?? [];
  answer = hits.length
    ? `The closest match in the study documentation is ${citationFor(hits[0]!)}:\n\n> ${hits[0]!.snippet}\n\nFor a figure from the trial data, try one of the sample questions or write the query directly in the SQL Workbench.`
    : `I couldn't route that question to a tool with confidence. Try one of the sample questions, or query the warehouse directly in the SQL Workbench. Available tables:\n\n${SCHEMA_DESCRIPTION}`;
  return { question, answer, trace: steps, citations: citationsFrom(steps), mode: "builtin" };
}
