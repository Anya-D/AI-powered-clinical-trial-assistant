/**
 * Plain-English translations of everything the app shows.
 * Deterministic, offline, and written for someone with no clinical, statistical
 * or database background.
 */
import type { TraceStep, AgentAnswer } from "./orchestrator";
import type { SurvivalAnalysis } from "./stats";
import { daysToMonths } from "./stats";
import type { DQReport } from "./dq";

export const PAGE_PLAIN: Record<string, { title: string; lines: string[] }> = {
  assistant: {
    title: "What this page does",
    lines: [
      "Type a question about the study the way you would ask a colleague — no special wording needed.",
      "The assistant picks the right helper for the job: looking things up in the study records, reading the study rule book, doing the survival maths, or checking the records for mistakes.",
      "It then shows you every step it took, so you can see exactly where each number came from instead of taking it on trust.",
      "Anything it quotes from the study documents is linked, so you can read the original wording yourself.",
    ],
  },
  survival: {
    title: "What this page shows",
    lines: [
      "This compares how long people lived (or stayed free of their cancer getting worse) on the new drug, ONC-501, versus the usual treatment.",
      "Each line starts at 100% of people and steps down every time someone's cancer comes back or they die. A line that stays higher for longer is the better result.",
      "\u201cMedian\u201d is the halfway point: the time by which half the group had the event. Here, half the people on ONC-501 reached it later than half the people on the usual treatment.",
      "Small ticks on the line mean someone left the study or was still doing fine when the data was collected — they are still counted, just not as an event.",
      "The p-value answers \u201ccould this difference just be luck?\u201d A small number (under 0.05) means luck is an unlikely explanation.",
      "The shaded band is the margin of uncertainty around each line — the true answer is likely somewhere inside it.",
    ],
  },
  sql: {
    title: "What this page does",
    lines: [
      "This is a place to ask the study database for exact lists and counts, using the database's own language (SQL).",
      "The list on the left shows the five sets of records available: people in the study, their visits, side effects, lab results and tumour markers.",
      "Pick a ready-made question from the list, press Run, and you get a table of results you can download as a spreadsheet.",
      "Nothing here can change or delete data — it can only read it.",
    ],
  },
  documents: {
    title: "What this page shows",
    lines: [
      "These are the study's official written rules and definitions — the paperwork every hospital in the study has to follow.",
      "The Protocol is the master plan: who can join, what treatment they get, and what counts as success.",
      "The Statistical Analysis Plan says in advance exactly how the results will be counted, so nobody can pick a flattering method afterwards.",
      "The Data Dictionary explains what every field in the records means, and the AE Definitions explain how side effects are graded.",
      "Search here to find the sentence the assistant quoted, in its original wording.",
    ],
  },
  quality: {
    title: "What this page shows",
    lines: [
      "This is a health check on the paperwork, not on the patients: it hunts for records that contradict each other or are missing.",
      "Examples: the same person entered twice, a visit dated before the person joined, or a lab value that no human could have.",
      "\u201cCritical\u201d means someone needs to go back to the hospital and ask what really happened. \u201cWarning\u201d means keep an eye on it.",
      "Every finding is produced by a fixed rule, the same way every time — no AI guessing is involved, so the results are checkable.",
      "The score out of 100 is a rough summary of how clean the records look overall.",
    ],
  },
  settings: {
    title: "What this page does",
    lines: [
      "The app already works on its own — it can answer questions, run the maths and check the records with no setup.",
      "If you paste in a key from Groq (an AI service), an AI model chooses which tool to use for each question instead of the built-in rules, which handles more unusual wording.",
      "Your key stays in this browser only, and is never shown to other people using the app.",
    ],
  },
};

const TOOL_PLAIN: Record<string, string> = {
  sql_query: "Looked up the actual records in the study database and counted what it found.",
  search_documentation:
    "Read the study's official documents and pulled out the passage that answers the question.",
  run_survival_analysis:
    "Worked out how long each group lived, properly accounting for people who were still fine at the end, and tested whether the difference could be luck.",
  data_quality_check:
    "Ran the fixed set of record-checking rules to see if anything in the data contradicts itself.",
};

/** One plain sentence per step of the assistant's work. */
export function explainStep(step: TraceStep): string {
  const base = TOOL_PLAIN[step.tool] ?? "Ran one of its tools.";
  if (step.result.error) return `${base} This step failed, so the answer does not rely on it.`;
  if (step.tool === "sql_query" && step.result.rowCount !== undefined) {
    return `${base} It came back with ${step.result.rowCount} ${
      step.result.rowCount === 1 ? "row" : "rows"
    } of matching records.`;
  }
  if (step.tool === "search_documentation" && step.result.hits?.length) {
    return `${base} It found ${step.result.hits.length} relevant ${
      step.result.hits.length === 1 ? "passage" : "passages"
    }.`;
  }
  return base;
}

/** Plain summary of a whole assistant answer. */
export function explainAnswer(answer: AgentAnswer): string[] {
  const lines: string[] = [];
  lines.push(`You asked: \u201c${answer.question}\u201d`);
  if (answer.trace.length) {
    lines.push(
      `To answer it the assistant took ${answer.trace.length} step${answer.trace.length === 1 ? "" : "s"}:`,
    );
    answer.trace.forEach((s, i) => lines.push(`Step ${i + 1}. ${explainStep(s)}`));
  }
  if (answer.citations.length) {
    lines.push(
      `The answer quotes ${answer.citations.length} section${answer.citations.length === 1 ? "" : "s"} of the study paperwork, linked below — you can click through and read the original.`,
    );
  } else {
    lines.push("The numbers above come straight from the study records, not from an AI guess.");
  }
  lines.push(
    answer.mode === "groq"
      ? "An AI model chose which tools to use, but every number was calculated by the app itself."
      : "No AI model was involved: the app matched your question to the right tool using fixed rules.",
  );
  const jargon = glossaryFor(answer.answer);
  if (jargon.length) lines.push(`Terms used above: ${jargon.join(" ")}`);
  return lines;
}

/** Plain reading of the survival results currently on screen. */
export function explainSurvival(a: SurvivalAnalysis): string[] {
  const [treat, control] = a.curves;
  const what =
    a.endpointLabel.toLowerCase().includes("progression")
      ? "living without their cancer getting worse"
      : "staying alive";
  const lines: string[] = [];
  if (treat?.median != null && control?.median != null) {
    const diff = treat.median - control.median;
    lines.push(
      `Half the people on ONC-501 were still ${what} at ${daysToMonths(treat.median).toFixed(1)} months, versus ${daysToMonths(control.median).toFixed(1)} months on the usual treatment.`,
    );
    lines.push(
      diff > 0
        ? `That is about ${daysToMonths(diff).toFixed(1)} months longer for the halfway point — roughly ${diff} extra days — in favour of the new drug.`
        : `The halfway point was not later on the new drug in this dataset.`,
    );
  } else {
    lines.push("Not enough people had the event yet to give a reliable halfway point for both groups.");
  }
  lines.push(
    a.logrank.pValue < 0.05
      ? `The difference is unlikely to be down to chance (about a ${(a.logrank.pValue * 100).toFixed(2)}% chance of seeing a gap this big if the two treatments were really equal).`
      : `This difference could plausibly be down to chance, so it is not treated as proven (about a ${(a.logrank.pValue * 100).toFixed(1)}% chance of seeing a gap this big by luck alone).`,
  );
  if (a.logrank.hazardRatio != null) {
    const hr = a.logrank.hazardRatio;
    lines.push(
      hr < 1
        ? `At any given moment, people on ONC-501 were roughly ${Math.round((1 - hr) * 100)}% less likely to have the event than people on the usual treatment.`
        : `At any given moment, people on ONC-501 were not at lower risk than people on the usual treatment.`,
    );
  }
  lines.push(
    `${treat?.events ?? 0} of ${treat?.n ?? 0} people on ONC-501 and ${control?.events ?? 0} of ${control?.n ?? 0} on the usual treatment had the event; everyone else was still event-free when the data was collected and is counted as such.`,
  );
  return lines;
}

/** Plain reading of the data quality report. */
export function explainQuality(r: DQReport): string[] {
  const critical = r.findings.filter((f) => f.severity === "critical").length;
  const warnings = r.findings.filter((f) => f.severity === "warning").length;
  const worst = [...r.siteMissingness].sort((a, b) => b.pct_missing - a.pct_missing)[0];
  const lines = [
    `${r.nPatients} people's records were checked against ${r.findings.length} rules.`,
    critical
      ? `${critical} ${critical === 1 ? "problem needs" : "problems need"} chasing up with the hospitals before the data can be trusted for a final analysis.`
      : "Nothing serious enough to block the analysis was found.",
    warnings
      ? `${warnings} ${warnings === 1 ? "issue is" : "issues are"} worth watching but do not block anything.`
      : "There are no lower-priority warnings either.",
  ];
  if (worst) {
    lines.push(
      `The hospital with the most missing tumour-marker results is ${worst.site_name || worst.site_id}, where ${worst.pct_missing.toFixed(1)}% of results were never recorded.`,
    );
  }
  if (r.reconciliation) {
    const un = r.reconciliation.unreconciled?.length ?? 0;
    if (un) {
      lines.push(
        `${un} ${un === 1 ? "person was" : "people were"} recorded as stopping treatment because of a side effect, but no side-effect record says it caused them to stop — the two forms disagree.`,
      );
    }
  }
  lines.push("Click any finding to see exactly who is affected and the rule that flagged it.");
  return lines;
}

/** Plain reading of a SQL result. */
export function explainSql(sql: string, rowCount: number, columns: string[]): string[] {
  const tables = [...new Set([...sql.matchAll(/\b(?:from|join)\s+([a-z_]+)/gi)].map((m) => m[1]))];
  const readable: Record<string, string> = {
    patients: "the people in the study",
    visits: "their clinic visits",
    adverse_events: "side effects that were reported",
    labs: "blood and lab test results",
    biomarkers: "tumour marker measurements",
  };
  const named = tables.map((t) => readable[t ?? ""] ?? t).filter(Boolean);
  return [
    named.length
      ? `This question asks the database about ${named.join(" and ")}.`
      : "This question reads from the study database.",
    `It came back with ${rowCount} ${rowCount === 1 ? "row" : "rows"}, one per result, showing ${columns.length} column${columns.length === 1 ? "" : "s"}: ${columns.join(", ")}.`,
    "Use Export CSV to open the same table in a spreadsheet.",
  ];
}

const GLOSSARY: { match: RegExp; text: string }[] = [
  { match: /\bmedian\b/i, text: "Median = the halfway point, not the average." },
  {
    match: /p[\s-]?value|p\s?=|log-?rank/i,
    text: "P-value = the chance of seeing a difference this big if the treatments were really equal; under 0.05 is usually called significant.",
  },
  {
    match: /censor/i,
    text: "Censored = the person had not had the event yet when the data was collected, so we only know they lasted at least that long.",
  },
  {
    match: /hazard ratio|\bHR\b/,
    text: "Hazard ratio = how the moment-to-moment risk compares between the two groups; below 1 favours the new drug.",
  },
  {
    match: /grade 3\+|CTCAE|grade \d/i,
    text: "Side effects are graded 1 to 5; grade 3 or above means severe or worse.",
  },
  {
    match: /progression-free survival|\bPFS\b/,
    text: "Progression-free survival = time until the cancer gets worse or the person dies, whichever comes first.",
  },
  {
    match: /overall survival|\bOS\b/,
    text: "Overall survival = time from joining the study until death from any cause.",
  },
  {
    match: /confidence interval|95% CI/i,
    text: "95% confidence interval = the range the true value is very likely to sit in.",
  },
  {
    match: /biomarker|PD-L1/i,
    text: "A biomarker such as PD-L1 is a measurement from the tumour used to predict who is likely to respond.",
  },
  {
    match: /intent-to-treat|\bITT\b/,
    text: "Intent-to-treat = everyone is counted in the group they were assigned to, even if they stopped treatment.",
  },
  {
    match: /discontinu/i,
    text: "Discontinuation = the person stopped their study treatment early.",
  },
];

export function glossaryFor(text: string): string[] {
  return GLOSSARY.filter((g) => g.match.test(text)).map((g) => g.text);
}
