/**
 * In-browser trial data warehouse.
 *
 * Loads the ONC-501-301 CSV extracts into an in-memory SQLite database
 * (sql.js / SQLite compiled to WebAssembly) so every figure in the app comes
 * from a real query against the study data.
 */
import initSqlJs, { type Database, type SqlJsStatic } from "sql.js";

export type Row = Record<string, string | number | null>;

export interface QueryResult {
  query: string;
  columns: string[];
  rows: Row[];
  rowCount: number;
  truncated: boolean;
}

export const MAX_ROWS = 500;

export const SCHEMA_DESCRIPTION = `Tables available (SQLite):

patients(patient_id, first_name, last_name, site_id, site_name, region,
         treatment_arm, age, sex, race, ecog_status, enrollment_date,
         discontinuation_reason, discontinuation_date,
         os_time_days, os_event, pfs_time_days, pfs_event)

visits(patient_id, visit_num, visit_date, tumor_sod_mm, baseline_sod_mm)

adverse_events(ae_id, patient_id, ae_term, soc, grade, serious,
               related_to_treatment, onset_date, resolution_date,
               led_to_discontinuation)

labs(lab_id, patient_id, visit_num, visit_date, test_name, result_value,
     ref_low, ref_high)

biomarkers(patient_id, pd_l1_status, pd_l1_tps_pct)

Notes: discontinuation_reason values include 'Death', 'Disease Progression',
'Adverse Event', 'Withdrawal by Subject', 'Physician Decision',
'Lost to Follow-up', 'Completed Study', 'Ongoing'. os_event/pfs_event are 1 if
the event (death / progression) was observed, 0 if censored. grade is CTCAE 1-5;
"Grade 3+" means grade >= 3. Boolean columns are stored as the text 'True'/'False'.`;

export interface TableSpec {
  name: string;
  file: string;
  columns: { name: string; type: "TEXT" | "INTEGER" | "REAL" }[];
  description: string;
}

export const TABLES: TableSpec[] = [
  {
    name: "patients",
    file: "/data/patients.csv",
    description: "One row per randomized patient (plus injected duplicate rows).",
    columns: [
      { name: "patient_id", type: "TEXT" },
      { name: "first_name", type: "TEXT" },
      { name: "last_name", type: "TEXT" },
      { name: "site_id", type: "TEXT" },
      { name: "site_name", type: "TEXT" },
      { name: "region", type: "TEXT" },
      { name: "treatment_arm", type: "TEXT" },
      { name: "age", type: "INTEGER" },
      { name: "sex", type: "TEXT" },
      { name: "race", type: "TEXT" },
      { name: "ecog_status", type: "INTEGER" },
      { name: "enrollment_date", type: "TEXT" },
      { name: "discontinuation_reason", type: "TEXT" },
      { name: "discontinuation_date", type: "TEXT" },
      { name: "os_time_days", type: "INTEGER" },
      { name: "os_event", type: "INTEGER" },
      { name: "pfs_time_days", type: "INTEGER" },
      { name: "pfs_event", type: "INTEGER" },
    ],
  },
  {
    name: "visits",
    file: "/data/visits.csv",
    description: "One row per scheduled tumor assessment visit.",
    columns: [
      { name: "patient_id", type: "TEXT" },
      { name: "visit_num", type: "INTEGER" },
      { name: "visit_date", type: "TEXT" },
      { name: "tumor_sod_mm", type: "REAL" },
      { name: "baseline_sod_mm", type: "REAL" },
    ],
  },
  {
    name: "adverse_events",
    file: "/data/adverse_events.csv",
    description: "One row per reported adverse event, CTCAE v5.0 graded.",
    columns: [
      { name: "ae_id", type: "TEXT" },
      { name: "patient_id", type: "TEXT" },
      { name: "ae_term", type: "TEXT" },
      { name: "soc", type: "TEXT" },
      { name: "grade", type: "INTEGER" },
      { name: "serious", type: "TEXT" },
      { name: "related_to_treatment", type: "TEXT" },
      { name: "onset_date", type: "TEXT" },
      { name: "resolution_date", type: "TEXT" },
      { name: "led_to_discontinuation", type: "TEXT" },
    ],
  },
  {
    name: "labs",
    file: "/data/labs.csv",
    description: "One row per lab test per scheduled visit.",
    columns: [
      { name: "lab_id", type: "TEXT" },
      { name: "patient_id", type: "TEXT" },
      { name: "visit_num", type: "INTEGER" },
      { name: "visit_date", type: "TEXT" },
      { name: "test_name", type: "TEXT" },
      { name: "result_value", type: "REAL" },
      { name: "ref_low", type: "REAL" },
      { name: "ref_high", type: "REAL" },
    ],
  },
  {
    name: "biomarkers",
    file: "/data/biomarkers.csv",
    description: "One row per patient, baseline PD-L1 testing.",
    columns: [
      { name: "patient_id", type: "TEXT" },
      { name: "pd_l1_status", type: "TEXT" },
      { name: "pd_l1_tps_pct", type: "REAL" },
    ],
  },
];

/** Minimal RFC-4180 CSV parser (handles quoted fields and embedded commas). */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else inQuotes = false;
      } else field += ch;
      continue;
    }
    if (ch === '"') inQuotes = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") field += ch;
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.length > 1 || (r[0] ?? "").trim() !== "");
}

const FORBIDDEN = /\b(insert|update|delete|drop|alter|create|attach|pragma|replace|truncate)\b/i;

/** Read-only guard, mirroring the Python SQLQueryTool's allowlist. */
export function validateQuery(query: string): string | null {
  const stripped = query.trim().replace(/;+\s*$/, "");
  const lower = stripped.toLowerCase();
  if (!lower.startsWith("select") && !lower.startsWith("with")) {
    return "Only SELECT (or WITH ... SELECT) statements are permitted.";
  }
  if (stripped.includes(";")) return "Multiple statements are not permitted.";
  if (FORBIDDEN.test(stripped)) {
    return "Query contains a disallowed keyword (only read queries are permitted).";
  }
  return null;
}

export class Warehouse {
  constructor(private db: Database) {}

  /** Run a validated read-only query. Throws on invalid SQL. */
  query(sql: string, maxRows = MAX_ROWS): QueryResult {
    const error = validateQuery(sql);
    if (error) throw new Error(error);
    const stmt = this.db.prepare(sql.trim().replace(/;+\s*$/, ""));
    const rows: Row[] = [];
    let columns: string[] = [];
    let total = 0;
    try {
      while (stmt.step()) {
        total++;
        if (rows.length < maxRows) {
          const obj = stmt.getAsObject() as Row;
          if (columns.length === 0) columns = Object.keys(obj);
          rows.push(obj);
        }
      }
      if (columns.length === 0) columns = stmt.getColumnNames();
    } finally {
      stmt.free();
    }
    return { query: sql, columns, rows, rowCount: total, truncated: total > rows.length };
  }

  /** Convenience: first cell of the first row as a number. */
  scalar(sql: string): number {
    const r = this.query(sql, 1);
    const first = r.rows[0];
    if (!first) return 0;
    const value = Object.values(first)[0];
    return typeof value === "number" ? value : Number(value ?? 0);
  }
}

let warehousePromise: Promise<Warehouse> | undefined;

async function build(): Promise<Warehouse> {
  const SQL: SqlJsStatic = await initSqlJs({ locateFile: () => "/sql-wasm.wasm" });
  const db = new SQL.Database();

  for (const table of TABLES) {
    const cols = table.columns.map((c) => `${c.name} ${c.type}`).join(", ");
    db.run(`CREATE TABLE ${table.name} (${cols})`);
  }

  const texts = await Promise.all(
    TABLES.map(async (t) => {
      const res = await fetch(t.file);
      if (!res.ok) throw new Error(`Failed to load ${t.file}`);
      return res.text();
    }),
  );

  db.run("BEGIN TRANSACTION");
  TABLES.forEach((table, index) => {
    const parsed = parseCsv(texts[index]!);
    const header = parsed[0]!;
    const placeholders = table.columns.map(() => "?").join(", ");
    const stmt = db.prepare(
      `INSERT INTO ${table.name} (${table.columns.map((c) => c.name).join(", ")}) VALUES (${placeholders})`,
    );
    const order = table.columns.map((c) => header.indexOf(c.name));
    for (let r = 1; r < parsed.length; r++) {
      const raw = parsed[r]!;
      const values = table.columns.map((col, ci) => {
        const idx = order[ci]!;
        const cell = idx >= 0 ? (raw[idx] ?? "") : "";
        if (cell === "") return null;
        if (col.type === "TEXT") return cell;
        const num = Number(cell);
        return Number.isNaN(num) ? null : num;
      });
      stmt.run(values as (string | number | null)[]);
      stmt.reset();
    }
    stmt.free();
  });
  db.run("COMMIT");

  for (const idx of [
    "CREATE INDEX idx_ae_patient ON adverse_events(patient_id)",
    "CREATE INDEX idx_visit_patient ON visits(patient_id)",
    "CREATE INDEX idx_lab_patient ON labs(patient_id)",
    "CREATE INDEX idx_bio_patient ON biomarkers(patient_id)",
  ]) {
    db.run(idx);
  }

  return new Warehouse(db);
}

/** Lazily initialise the warehouse once per browser session. */
export function getWarehouse(): Promise<Warehouse> {
  if (!warehousePromise) warehousePromise = build();
  return warehousePromise;
}

export function toCsv(columns: string[], rows: Row[]): string {
  const escape = (value: string | number | null) => {
    const s = value === null || value === undefined ? "" : String(value);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [
    columns.join(","),
    ...rows.map((r) => columns.map((c) => escape(r[c] ?? null)).join(",")),
  ].join("\n");
}
