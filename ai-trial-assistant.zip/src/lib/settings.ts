/** Browser-local assistant settings. The Groq key never leaves the user's browser
 *  except on the request that calls Groq on their behalf. */

export const DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b";

const KEY_STORAGE = "trialassist.groq.key";
const MODEL_STORAGE = "trialassist.groq.model";

export interface AssistantSettings {
  apiKey: string;
  model: string;
}

export function readSettings(): AssistantSettings {
  if (typeof window === "undefined") return { apiKey: "", model: DEFAULT_GROQ_MODEL };
  return {
    apiKey: window.localStorage.getItem(KEY_STORAGE) ?? "",
    model: window.localStorage.getItem(MODEL_STORAGE) ?? DEFAULT_GROQ_MODEL,
  };
}

export function writeSettings(settings: AssistantSettings) {
  if (typeof window === "undefined") return;
  if (settings.apiKey) window.localStorage.setItem(KEY_STORAGE, settings.apiKey);
  else window.localStorage.removeItem(KEY_STORAGE);
  window.localStorage.setItem(MODEL_STORAGE, settings.model || DEFAULT_GROQ_MODEL);
}
