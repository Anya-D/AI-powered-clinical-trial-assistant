/**
 * Survival statistics ported from the project's stats_agent.py:
 * Kaplan-Meier estimation with Greenwood standard errors and log-log
 * confidence limits, median survival, and a two-group log-rank test.
 * No statistics library — the methods are implemented from first principles.
 */

export interface KMPoint {
  time: number;
  atRisk: number;
  events: number;
  censored: number;
  survival: number;
  se: number;
  ciLower: number;
  ciUpper: number;
}

export interface KMCurve {
  label: string;
  n: number;
  events: number;
  censored: number;
  points: KMPoint[];
  /** Times at which a censoring occurred, paired with the survival at that time. */
  censorMarks: { time: number; survival: number }[];
  median: number | null;
  medianCi: [number | null, number | null];
  maxTime: number;
}

export interface LogRank {
  chi2: number;
  pValue: number;
  observedA: number;
  expectedA: number;
  hazardRatio: number | null;
}

export interface SurvivalAnalysis {
  endpoint: "os" | "pfs";
  endpointLabel: string;
  curves: KMCurve[];
  logrank: LogRank;
  medianDifferenceDays: number | null;
  landmarks: { label: string; months: number; byArm: Record<string, number | null> }[];
}

export interface SurvivalRecord {
  time: number;
  event: number;
  group: string;
}

export function kaplanMeier(records: { time: number; event: number }[], label: string): KMCurve {
  const sorted = [...records].sort((a, b) => a.time - b.time);
  const n = sorted.length;
  const eventTimes = Array.from(
    new Set(sorted.filter((r) => r.event === 1).map((r) => r.time)),
  ).sort((a, b) => a - b);

  let survival = 1;
  let greenwood = 0;
  const points: KMPoint[] = [
    {
      time: 0,
      atRisk: n,
      events: 0,
      censored: 0,
      survival: 1,
      se: 0,
      ciLower: 1,
      ciUpper: 1,
    },
  ];

  for (const t of eventTimes) {
    const atRisk = sorted.filter((r) => r.time >= t).length;
    const d = sorted.filter((r) => r.time === t && r.event === 1).length;
    const c = sorted.filter((r) => r.time === t && r.event === 0).length;
    if (atRisk === 0) continue;
    survival *= 1 - d / atRisk;
    if (atRisk > d) greenwood += d / (atRisk * (atRisk - d));
    const se = survival * Math.sqrt(greenwood);
    let lower = survival;
    let upper = survival;
    if (survival > 0 && survival < 1) {
      const inner = (1.96 * se) / (survival * Math.log(survival));
      lower = clamp(Math.pow(survival, Math.exp(inner)), 0, 1);
      upper = clamp(Math.pow(survival, Math.exp(-inner)), 0, 1);
    }
    points.push({
      time: t,
      atRisk,
      events: d,
      censored: c,
      survival,
      se,
      ciLower: lower,
      ciUpper: upper,
    });
  }

  const censorMarks = sorted
    .filter((r) => r.event === 0)
    .map((r) => ({ time: r.time, survival: survivalAt(points, r.time) }));

  const median = medianSurvival(points);
  return {
    label,
    n,
    events: sorted.filter((r) => r.event === 1).length,
    censored: sorted.filter((r) => r.event === 0).length,
    points,
    censorMarks,
    median,
    medianCi: medianCi(points),
    maxTime: sorted.length ? sorted[sorted.length - 1]!.time : 0,
  };
}

function clamp(v: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, v));
}

export function survivalAt(points: KMPoint[], time: number): number {
  let s = 1;
  for (const p of points) {
    if (p.time <= time) s = p.survival;
    else break;
  }
  return s;
}

export function medianSurvival(points: KMPoint[]): number | null {
  const hit = points.find((p) => p.survival <= 0.5);
  return hit ? hit.time : null;
}

function medianCi(points: KMPoint[]): [number | null, number | null] {
  const lower = points.find((p) => p.ciUpper <= 0.5);
  const upper = points.find((p) => p.ciLower <= 0.5);
  return [lower ? lower.time : null, upper ? upper.time : null];
}

/** Regularized upper incomplete gamma-based chi-square survival function, df=1. */
export function chiSquarePValue(chi2: number, df = 1): number {
  if (chi2 <= 0) return 1;
  if (df === 1) return erfc(Math.sqrt(chi2 / 2));
  return Math.exp(-chi2 / 2);
}

function erfc(x: number): number {
  // Numerical Recipes incomplete-gamma based complementary error function.
  const z = Math.abs(x);
  const t = 2 / (2 + z);
  const ty = 4 * t - 2;
  const cof = [
    -1.3026537197817, 6.419697923565e-1, 1.9476473204186e-2, -9.561514786809e-3,
    -9.46595344482036e-4, 3.66839497852761e-4, 4.2523324806907e-5, -2.0278578112534e-5,
    -1.624290004647e-6, 1.30365583558e-6, 1.5626441722e-8, -8.5238095915e-8, 6.529054439e-9,
    5.059343495e-9, -9.91364156e-10, -2.27365122e-10, 9.6467911e-11, 2.394038e-12, -6.886027e-12,
    8.94487e-13, 3.13092e-13, -1.12708e-13, 3.81e-16, 7.106e-15,
  ];
  let d = 0;
  let dd = 0;
  for (let j = cof.length - 1; j > 0; j--) {
    const tmp = d;
    d = ty * d - dd + cof[j]!;
    dd = tmp;
  }
  const ans = t * Math.exp(-z * z + 0.5 * (cof[0]! + ty * d) - dd);
  return x >= 0 ? ans : 2 - ans;
}

export function logRankTest(
  groupA: { time: number; event: number }[],
  groupB: { time: number; event: number }[],
): LogRank {
  const all = [
    ...groupA.map((r) => ({ ...r, g: "A" as const })),
    ...groupB.map((r) => ({ ...r, g: "B" as const })),
  ];
  const eventTimes = Array.from(new Set(all.filter((r) => r.event === 1).map((r) => r.time))).sort(
    (a, b) => a - b,
  );

  let oMinusE = 0;
  let variance = 0;
  let observedA = 0;
  let expectedA = 0;
  let expectedB = 0;
  let observedB = 0;

  for (const t of eventTimes) {
    const atRiskA = all.filter((r) => r.g === "A" && r.time >= t).length;
    const atRiskB = all.filter((r) => r.g === "B" && r.time >= t).length;
    const nAtRisk = atRiskA + atRiskB;
    const dA = all.filter((r) => r.g === "A" && r.time === t && r.event === 1).length;
    const dB = all.filter((r) => r.g === "B" && r.time === t && r.event === 1).length;
    const d = dA + dB;
    if (nAtRisk <= 1 || d === 0) continue;
    const eA = (d * atRiskA) / nAtRisk;
    const eB = (d * atRiskB) / nAtRisk;
    const varT = (d * (atRiskA / nAtRisk) * (atRiskB / nAtRisk) * (nAtRisk - d)) / (nAtRisk - 1);
    oMinusE += dA - eA;
    variance += varT;
    observedA += dA;
    observedB += dB;
    expectedA += eA;
    expectedB += eB;
  }

  if (variance === 0) {
    return { chi2: 0, pValue: 1, observedA, expectedA, hazardRatio: null };
  }
  const chi2 = (oMinusE * oMinusE) / variance;
  const hazardRatio =
    expectedA > 0 && expectedB > 0 && observedB > 0
      ? observedA / expectedA / (observedB / expectedB)
      : null;
  return {
    chi2,
    pValue: chiSquarePValue(chi2, 1),
    observedA,
    expectedA,
    hazardRatio,
  };
}

const ARMS = ["ONC-501", "Standard of Care"];

export function survivalAnalysis(
  records: SurvivalRecord[],
  endpoint: "os" | "pfs",
): SurvivalAnalysis {
  const curves = ARMS.map((arm) =>
    kaplanMeier(
      records.filter((r) => r.group === arm).map((r) => ({ time: r.time, event: r.event })),
      arm,
    ),
  );
  const a = records.filter((r) => r.group === ARMS[0]);
  const b = records.filter((r) => r.group === ARMS[1]);
  const logrank = logRankTest(a, b);
  const [treat, control] = curves;
  const medianDifferenceDays =
    treat?.median != null && control?.median != null ? treat.median - control.median : null;

  const landmarks = [6, 12, 24].map((months) => ({
    label: `${months}-month`,
    months,
    byArm: Object.fromEntries(
      curves.map((c) => [
        c.label,
        c.maxTime >= months * 30.44 ? survivalAt(c.points, months * 30.44) : null,
      ]),
    ),
  }));

  return {
    endpoint,
    endpointLabel: endpoint === "os" ? "Overall Survival" : "Progression-Free Survival",
    curves,
    logrank,
    medianDifferenceDays,
    landmarks,
  };
}

export function formatP(p: number): string {
  if (p < 0.0001) return "< 0.0001";
  if (p < 0.001) return p.toExponential(2);
  return p.toFixed(4);
}

export function daysToMonths(days: number): number {
  return days / 30.44;
}
