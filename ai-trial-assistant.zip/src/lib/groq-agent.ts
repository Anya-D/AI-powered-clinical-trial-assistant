/**
 * Groq-backed agent loop. Tools execute locally against the in-browser
 * warehouse; each model turn is routed through the groqTurn server function.
 */
import { groqTurn, type GroqToolCall } from "./groq.functions";
import {
  answerOffline,
  toolDataQuality,
  toolSearchDocs,
  toolSqlQuery,
  toolSurvival,
  type AgentAnswer,
  type TraceStep,
  type ToolName,
} from "./orchestrator";
import { SCHEMA_DESCRIPTION, type Warehouse } from "./warehouse";

const SYSTEM_PROMPT = `You are TrialAssist, a clinical trial data assistant for study ONC-501-301. You help clinical data managers and biostatisticians answer questions about trial data and documentation.

Tools:
1. sql_query — run a read-only SQL SELECT against the trial database for counts, filters, demographics and lookups. The patients table contains a small number of injected duplicate rows; de-duplicate on patient_id when counting patients.
2. search_documentation — retrieve passages from the protocol, data dictionary, statistical analysis plan and AE definitions, with citations.
3. run_survival_analysis — Kaplan-Meier with a log-rank test comparing arms on OS or PFS. Use this for any survival / time-to-event / "how much longer did patients live" question; never approximate it with AVG(os_time_days), which ignores censoring.
4. data_quality_check — run the deterministic data quality battery.

Database schema for sql_query:
${SCHEMA_DESCRIPTION}

Guidelines:
- Choose the right tool(s). Definitional questions need search_documentation; count/filter questions need sql_query; survival comparisons need run_survival_analysis.
- Cite the source document and section whenever you use search_documentation.
- Base every number on a tool result. Never state a figure you did not get from a tool.
- Be concise and precise: lead with the number or fact, then brief supporting detail.`;

const TOOL_DEFS = [
  {
    type: "function",
    function: {
      name: "sql_query",
      description: "Run a read-only SQL SELECT query against the trial database.",
      parameters: {
        type: "object",
        properties: { query: { type: "string", description: "A SQL SELECT statement." } },
        required: ["query"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "search_documentation",
      description:
        "Retrieve relevant passages from study documentation (protocol, data dictionary, SAP, AE definitions) with citations.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "Natural-language question or topic." },
        },
        required: ["query"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "run_survival_analysis",
      description:
        "Kaplan-Meier survival analysis plus log-rank test comparing treatment arms on overall survival (OS) or progression-free survival (PFS).",
      parameters: {
        type: "object",
        properties: {
          endpoint: { type: "string", enum: ["os", "pfs"], description: "'os' or 'pfs'." },
        },
        required: ["endpoint"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "data_quality_check",
      description: "Run the deterministic data quality check battery over the warehouse.",
      parameters: { type: "object", properties: {}, required: [] },
    },
  },
];

type ChatMessage = {
  role: "system" | "user" | "assistant" | "tool";
  content?: string | null;
  tool_call_id?: string;
  tool_calls?: { id: string; type: "function"; function: { name: string; arguments: string } }[];
};

function dispatch(wh: Warehouse, call: GroqToolCall, index: number): TraceStep {
  let args: Record<string, unknown> = {};
  try {
    args = JSON.parse(call.arguments || "{}") as Record<string, unknown>;
  } catch {
    args = {};
  }
  const rationale = "Selected by the model for this step.";
  switch (call.name as ToolName) {
    case "sql_query":
      return toolSqlQuery(wh, String(args["query"] ?? ""), rationale, index);
    case "search_documentation":
      return toolSearchDocs(String(args["query"] ?? ""), rationale, index);
    case "run_survival_analysis":
      return toolSurvival(wh, args["endpoint"] === "pfs" ? "pfs" : "os", rationale, index);
    case "data_quality_check":
      return toolDataQuality(wh, rationale, index);
    default:
      return {
        index,
        tool: "sql_query",
        rationale,
        input: args,
        result: { summary: "Unknown tool", error: `Unknown tool: ${call.name}` },
        durationMs: 0,
      };
  }
}

function serializeForModel(step: TraceStep): string {
  const { result } = step;
  if (result.error) return JSON.stringify({ error: result.error });
  if (result.survival) {
    const a = result.survival;
    return JSON.stringify({
      endpoint: a.endpointLabel,
      arms: a.curves.map((c) => ({
        arm: c.label,
        n: c.n,
        events: c.events,
        censored: c.censored,
        median_days: c.median,
      })),
      median_difference_days: a.medianDifferenceDays,
      logrank_chi2: Number(a.logrank.chi2.toFixed(4)),
      logrank_p_value: a.logrank.pValue,
      hazard_ratio: a.logrank.hazardRatio,
    });
  }
  if (result.hits) {
    return JSON.stringify(
      result.hits.map((h) => ({
        document: h.docTitle,
        section: h.section,
        text: h.text.slice(0, 1200),
      })),
    );
  }
  return JSON.stringify({
    row_count: result.rowCount,
    truncated: result.truncated,
    columns: result.columns,
    rows: (result.rows ?? []).slice(0, 60),
    metrics: result.metrics,
  });
}

export async function answerWithGroq(
  wh: Warehouse,
  question: string,
  apiKey: string,
  model: string,
  onStep?: (step: TraceStep) => void,
): Promise<AgentAnswer> {
  const messages: ChatMessage[] = [
    { role: "system", content: SYSTEM_PROMPT },
    { role: "user", content: question },
  ];
  const trace: TraceStep[] = [];
  let index = 1;

  for (let turn = 0; turn < 8; turn++) {
    const result = await groqTurn({
      data: { apiKey, model, messages: messages as never, tools: TOOL_DEFS as never },
    });

    if (!result.ok) {
      const fallback = answerOffline(wh, question);
      return {
        ...fallback,
        answer: `Groq request failed: ${result.error}\n\nAnswered with the built-in orchestrator instead.\n\n${fallback.answer}`,
      };
    }

    if (result.toolCalls.length === 0) {
      return {
        question,
        answer: result.content || "The model returned an empty response.",
        trace,
        citations: trace.flatMap((s) =>
          (s.result.hits ?? []).map((h) => ({
            document: h.docTitle,
            section: h.section,
            docId: h.docId,
          })),
        ),
        mode: "groq",
        model,
      };
    }

    messages.push({
      role: "assistant",
      content: result.content || null,
      tool_calls: result.toolCalls.map((c) => ({
        id: c.id,
        type: "function" as const,
        function: { name: c.name, arguments: c.arguments },
      })),
    });

    for (const call of result.toolCalls) {
      const step = dispatch(wh, call, index++);
      trace.push(step);
      onStep?.(step);
      messages.push({ role: "tool", tool_call_id: call.id, content: serializeForModel(step) });
    }
  }

  return {
    question,
    answer: "The agent reached its step limit without producing a final answer.",
    trace,
    citations: [],
    mode: "groq",
    model,
  };
}
