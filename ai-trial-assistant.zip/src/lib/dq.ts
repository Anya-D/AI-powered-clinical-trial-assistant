/**
 * Deterministic data quality checks, ported from data_quality_agent.py.
 * Rule-based and reproducible by design — no model involvement.
 */
import type { Warehouse } from "./warehouse";

export type Severity = "critical" | "warning" | "info";

export interface DQFinding {
  check: string;
  severity: Severity;
  count: number;
  detail: string;
  affectedIds: string[];
  sql?: string;
}

export interface SiteMissingness {
  site_id: string;
  site_name: string;
  n_patients: number;
  n_missing: number;
  pct_missing: number;
}

export interface DQReport {
  nPatients: number;
  qualityScore: number;
  findings: DQFinding[];
  siteMissingness: SiteMissingness[];
  reconciliation: {
    aeDiscontinuationEvents: number;
    patientsWithAeDiscontinuationEvent: number;
    patientsWithAeDiscontinuationReason: number;
    unreconciled: string[];
    orphanReason: string[];
  };
}

const str = (v: string | number | null | undefined) =>
  v === null || v === undefined ? "" : String(v);

export function runDataQuality(wh: Warehouse): DQReport {
  const findings: DQFinding[] = [];

  const dupSql = `SELECT patient_id, COUNT(*) AS c FROM patients GROUP BY patient_id HAVING c > 1`;
  const dup = wh.query(dupSql);
  findings.push({
    check: "Duplicate patient records",
    severity: dup.rowCount ? "critical" : "info",
    count: dup.rows.reduce((sum, r) => sum + (Number(r["c"]) - 1), 0),
    detail: `${dup.rowCount} patient_id(s) appear more than once in the patients table.`,
    affectedIds: dup.rows.map((r) => str(r["patient_id"])),
    sql: dupSql,
  });

  const armSql = `SELECT patient_id, COUNT(DISTINCT treatment_arm) AS n_arms FROM patients GROUP BY patient_id HAVING n_arms > 1`;
  const arm = wh.query(armSql);
  findings.push({
    check: "Treatment arm inconsistencies",
    severity: arm.rowCount ? "critical" : "info",
    count: arm.rowCount,
    detail: `${arm.rowCount} patient(s) have conflicting treatment_arm values across records.`,
    affectedIds: arm.rows.map((r) => str(r["patient_id"])),
    sql: armSql,
  });

  const visitSql = `SELECT v.patient_id, v.visit_num, v.visit_date, p.enrollment_date
FROM visits v JOIN patients p ON p.patient_id = v.patient_id
WHERE date(v.visit_date) < date(p.enrollment_date)`;
  const visitDates = wh.query(visitSql);
  findings.push({
    check: "Invalid visit dates (visit before enrollment)",
    severity: visitDates.rowCount ? "critical" : "info",
    count: visitDates.rowCount,
    detail: `${visitDates.rowCount} visit record(s) are dated before the patient's enrollment date.`,
    affectedIds: Array.from(new Set(visitDates.rows.map((r) => str(r["patient_id"])))),
    sql: visitSql,
  });

  const labSql = `SELECT lab_id, patient_id, test_name, result_value, ref_low, ref_high
FROM labs WHERE result_value < 0 OR result_value > (ref_high * 20)`;
  const labs = wh.query(labSql);
  findings.push({
    check: "Impossible / implausible lab values",
    severity: labs.rowCount ? "critical" : "info",
    count: labs.rowCount,
    detail: `${labs.rowCount} lab result(s) are negative or implausibly extreme (> 20x reference high).`,
    affectedIds: labs.rows.map((r) => str(r["lab_id"])),
    sql: labSql,
  });

  const bioSql = `SELECT p.site_id, p.site_name, COUNT(*) AS n_patients,
       SUM(CASE WHEN b.pd_l1_status IS NULL OR b.pd_l1_status = '' THEN 1 ELSE 0 END) AS n_missing
FROM patients p LEFT JOIN biomarkers b ON b.patient_id = p.patient_id
GROUP BY p.site_id, p.site_name`;
  const bio = wh.query(bioSql);
  const siteMissingness: SiteMissingness[] = bio.rows
    .map((r) => {
      const n = Number(r["n_patients"]);
      const m = Number(r["n_missing"]);
      return {
        site_id: str(r["site_id"]),
        site_name: str(r["site_name"]),
        n_patients: n,
        n_missing: m,
        pct_missing: n ? Math.round((m / n) * 1000) / 10 : 0,
      };
    })
    .sort((a, b) => b.pct_missing - a.pct_missing);
  const totalPatients = siteMissingness.reduce((s, r) => s + r.n_patients, 0);
  const totalMissing = siteMissingness.reduce((s, r) => s + r.n_missing, 0);
  const overallPct = totalPatients ? Math.round((totalMissing / totalPatients) * 1000) / 10 : 0;
  const worst = siteMissingness
    .slice(0, 3)
    .map((r) => `${r.site_name} (${r.pct_missing}%)`)
    .join("; ");
  findings.push({
    check: "Missing biomarker (PD-L1) measurements by site",
    severity: overallPct > 5 ? "warning" : "info",
    count: totalMissing,
    detail: `Overall ${overallPct}% missing across all sites. Highest: ${worst}.`,
    affectedIds: siteMissingness.map((r) => r.site_id),
    sql: bioSql,
  });

  const seq = wh.query(
    "SELECT patient_id, visit_num FROM visits ORDER BY patient_id, visit_num",
    100000,
  );
  const byPatient = new Map<string, number[]>();
  for (const r of seq.rows) {
    const pid = str(r["patient_id"]);
    const list = byPatient.get(pid) ?? [];
    list.push(Number(r["visit_num"]));
    byPatient.set(pid, list);
  }
  const gapPatients: string[] = [];
  let gapCount = 0;
  for (const [pid, nums] of byPatient) {
    const sortedNums = [...nums].sort((a, b) => a - b);
    const expected = sortedNums[sortedNums.length - 1]! - sortedNums[0]! + 1;
    const missing = expected - new Set(sortedNums).size;
    if (missing > 0) {
      gapPatients.push(pid);
      gapCount += missing;
    }
  }
  findings.push({
    check: "Missing scheduled visit records (sequence gaps)",
    severity: gapCount ? "warning" : "info",
    count: gapCount,
    detail: `${gapCount} missing visit record(s) across ${gapPatients.length} patient(s), detected as gaps in the expected visit sequence.`,
    affectedIds: gapPatients,
  });

  const tumorSql = `SELECT COUNT(*) AS n, SUM(CASE WHEN tumor_sod_mm IS NULL THEN 1 ELSE 0 END) AS missing FROM visits`;
  const tumor = wh.query(tumorSql).rows[0]!;
  const nVisits = Number(tumor["n"]);
  const missingTumor = Number(tumor["missing"]);
  findings.push({
    check: "Missing tumor assessment values",
    severity: "info",
    count: missingTumor,
    detail: `${nVisits ? Math.round((missingTumor / nVisits) * 1000) / 10 : 0}% of recorded visits have a missing tumor SOD measurement.`,
    affectedIds: [],
    sql: tumorSql,
  });

  const nPatients = wh.scalar("SELECT COUNT(DISTINCT patient_id) FROM patients");
  const penalty = findings.reduce((sum, f) => {
    const weight = f.severity === "critical" ? 3 : f.severity === "warning" ? 1 : 0;
    return sum + weight * f.count;
  }, 0);
  const qualityScore = Math.max(0, 100 - (penalty / Math.max(1, nPatients)) * 10);

  // AE ↔ discontinuation reconciliation
  const aeDisc = wh.query(
    `SELECT DISTINCT patient_id FROM adverse_events WHERE led_to_discontinuation = 'True'`,
    10000,
  );
  const aeDiscPatients = new Set(aeDisc.rows.map((r) => str(r["patient_id"])));
  const reasonDisc = wh.query(
    `SELECT DISTINCT patient_id FROM patients WHERE discontinuation_reason = 'Adverse Event'`,
    10000,
  );
  const reasonPatients = new Set(reasonDisc.rows.map((r) => str(r["patient_id"])));
  const aeEventCount = wh.scalar(
    `SELECT COUNT(*) FROM adverse_events WHERE led_to_discontinuation = 'True'`,
  );

  return {
    nPatients,
    qualityScore: Math.round(qualityScore * 10) / 10,
    findings,
    siteMissingness,
    reconciliation: {
      aeDiscontinuationEvents: aeEventCount,
      patientsWithAeDiscontinuationEvent: aeDiscPatients.size,
      patientsWithAeDiscontinuationReason: reasonPatients.size,
      unreconciled: [...aeDiscPatients].filter((p) => !reasonPatients.has(p)).sort(),
      orphanReason: [...reasonPatients].filter((p) => !aeDiscPatients.has(p)).sort(),
    },
  };
}
