import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { PlainEnglishButton } from "./plain-english";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div className="max-w-2xl">
        <h1 className="text-[22px] font-semibold tracking-tight">{title}</h1>
        <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">{description}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <PlainEnglishButton />
        {actions}
      </div>
    </div>
  );
}

export function Panel({
  title,
  subtitle,
  actions,
  children,
  className,
  bodyClassName,
}: {
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <section
      className={cn("overflow-hidden rounded-lg border border-border bg-surface", className)}
    >
      {title ? (
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-surface-strong px-4 py-2.5">
          <div>
            <h2 className="text-[13px] font-semibold tracking-tight">{title}</h2>
            {subtitle ? (
              <p className="mt-0.5 text-[11px] text-muted-foreground">{subtitle}</p>
            ) : null}
          </div>
          {actions}
        </header>
      ) : null}
      <div className={cn("p-4", bodyClassName)}>{children}</div>
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "treatment" | "control" | "critical" | "warning";
}) {
  const valueTone = {
    default: "text-foreground",
    treatment: "text-arm-treatment",
    control: "text-arm-control",
    critical: "text-critical",
    warning: "text-warning",
  }[tone];
  return (
    <div className="rounded-lg border border-border bg-surface px-4 py-3">
      <div className="label-caps">{label}</div>
      <div className={cn("mt-1.5 text-[21px] leading-none font-semibold tnum", valueTone)}>
        {value}
      </div>
      {hint ? <div className="mt-1.5 text-[11px] text-muted-foreground">{hint}</div> : null}
    </div>
  );
}

export function SeverityBadge({ severity }: { severity: "critical" | "warning" | "info" }) {
  const styles = {
    critical: "border-critical/40 bg-critical/10 text-critical",
    warning: "border-warning/45 bg-warning/12 text-warning",
    info: "border-border bg-secondary text-muted-foreground",
  }[severity];
  return (
    <span
      className={cn(
        "inline-flex items-center rounded border px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.06em] uppercase",
        styles,
      )}
    >
      {severity}
    </span>
  );
}

export function Code({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <pre
      className={cn(
        "overflow-x-auto rounded-md border border-border bg-surface-strong p-3 font-mono text-[12px] leading-relaxed whitespace-pre-wrap",
        className,
      )}
    >
      {children}
    </pre>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border px-6 py-10 text-center">
      <p className="text-[13px] font-medium">{title}</p>
      <p className="mx-auto mt-1 max-w-md text-[12px] text-muted-foreground">{body}</p>
    </div>
  );
}

export function LoadingWarehouse() {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-border bg-surface px-6 py-16 text-center">
      <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
      <p className="mt-3 text-[13px] font-medium">Loading the trial data warehouse</p>
      <p className="mt-1 text-[12px] text-muted-foreground">
        Reading the ONC-501-301 extracts into the in-browser SQLite engine.
      </p>
    </div>
  );
}
