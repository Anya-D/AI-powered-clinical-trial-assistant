import type { Row } from "@/lib/warehouse";

export function DataGrid({
  columns,
  rows,
  maxHeight = 420,
}: {
  columns: string[];
  rows: Row[];
  maxHeight?: number;
}) {
  if (rows.length === 0) {
    return (
      <div className="rounded border border-dashed border-border px-4 py-6 text-center text-[12px] text-muted-foreground">
        No rows returned.
      </div>
    );
  }
  return (
    <div className="overflow-auto rounded border border-border bg-surface" style={{ maxHeight }}>
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {columns.map((c) => {
                const value = row[c];
                const isNumber = typeof value === "number";
                return (
                  <td
                    key={c}
                    className={
                      isNumber
                        ? "text-right tnum"
                        : value === null
                          ? "text-muted-foreground italic"
                          : ""
                    }
                  >
                    {value === null || value === undefined ? "—" : String(value)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
