import { useMemo, useState } from "react";
import { Plus, Sparkles, Wand2, X } from "lucide-react";
import { toast } from "sonner";
import { Panel } from "./primitives";
import { cn } from "@/lib/utils";
import { TABLES, type Warehouse } from "@/lib/warehouse";
import {
  BUILDER_EXAMPLES,
  BUILDER_MODES,
  DEFAULT_SPEC,
  FILTER_OPS,
  buildSql,
  describeSpec,
  numericColumns,
  suggestSql,
  tableSpec,
  type BuilderSpec,
} from "@/lib/query-builder";

const selectCls =
  "rounded-md border border-border bg-surface px-2 py-1.5 text-[12.5px] outline-none focus:border-primary";

export function QueryHelper({
  warehouse,
  onUse,
}: {
  warehouse: Warehouse | null;
  onUse: (sql: string) => void;
}) {
  const [tab, setTab] = useState<"ask" | "build">("ask");
  const [question, setQuestion] = useState("");
  const [suggestion, setSuggestion] = useState<{ sql: string; explanation: string } | null>(null);
  const [noMatch, setNoMatch] = useState(false);
  const [spec, setSpec] = useState<BuilderSpec>(DEFAULT_SPEC);

  const columns = useMemo(() => tableSpec(spec.table).columns.map((c) => c.name), [spec.table]);
  const numerics = useMemo(() => numericColumns(spec.table), [spec.table]);
  const builtSql = useMemo(() => buildSql(spec), [spec]);

  function ask(text: string) {
    const q = text.trim();
    if (!q) return;
    if (!warehouse) {
      toast.error("The study data is still loading — try again in a moment.");
      return;
    }
    const s = suggestSql(warehouse, q);
    if (!s) {
      setSuggestion(null);
      setNoMatch(true);
      return;
    }
    setNoMatch(false);
    setSuggestion({ sql: s.sql, explanation: s.explanation });
  }

  function patch(next: Partial<BuilderSpec>) {
    setSpec((prev) => ({ ...prev, ...next }));
  }

  return (
    <Panel
      title="Write the query for me"
      subtitle="No SQL needed — describe what you want in plain words, or point and click."
      actions={
        <div className="flex items-center gap-1 rounded-md border border-border bg-surface p-0.5">
          {(
            [
              ["ask", "Describe it"],
              ["build", "Point and click"],
            ] as const
          ).map(([value, label]) => (
            <button
              key={value}
              type="button"
              onClick={() => setTab(value)}
              className={cn(
                "rounded px-2.5 py-1 text-[12px] font-medium",
                tab === value
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {label}
            </button>
          ))}
        </div>
      }
    >
      {tab === "ask" ? (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex min-w-[220px] flex-1 items-center gap-2 rounded-md border border-border bg-surface px-2.5 py-1.5">
              <Sparkles className="h-3.5 w-3.5 shrink-0 text-primary" />
              <input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") ask(question);
                }}
                placeholder="e.g. How many patients stopped treatment because of side effects?"
                className="w-full bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
              />
            </div>
            <button
              type="button"
              onClick={() => ask(question)}
              className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-[12px] font-medium text-primary-foreground"
            >
              <Wand2 className="h-3.5 w-3.5" /> Write the SQL
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {BUILDER_EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => {
                  setQuestion(ex);
                  ask(ex);
                }}
                className="rounded-full border border-border bg-surface px-2.5 py-1 text-[11.5px] text-muted-foreground hover:border-primary/50 hover:text-foreground"
              >
                {ex}
              </button>
            ))}
          </div>

          {noMatch ? (
            <p className="rounded-md border border-warning/40 bg-warning/10 px-3 py-2 text-[12.5px] text-foreground">
              I couldn&apos;t turn that into a database query. Try mentioning what you want counted
              (patients, visits, side effects, lab results) — or use <strong>Point and click</strong>{" "}
              to assemble it step by step.
            </p>
          ) : null}

          {suggestion ? (
            <div className="rounded-md border border-border bg-surface-strong/60 p-3">
              <p className="mb-2 text-[12.5px] text-muted-foreground">{suggestion.explanation}</p>
              <pre className="overflow-x-auto rounded bg-surface p-2.5 font-mono text-[12px] leading-relaxed">
                {suggestion.sql}
              </pre>
              <button
                type="button"
                onClick={() => {
                  onUse(suggestion.sql);
                  toast.success("Query loaded into the editor");
                }}
                className="mt-2.5 rounded-md bg-primary px-3 py-1.5 text-[12px] font-medium text-primary-foreground"
              >
                Use this query
              </button>
            </div>
          ) : null}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-[12.5px]">
            <span className="text-muted-foreground">I want to</span>
            <select
              value={spec.mode}
              onChange={(e) => patch({ mode: e.target.value as BuilderSpec["mode"] })}
              className={selectCls}
            >
              {BUILDER_MODES.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
            <span className="text-muted-foreground">from</span>
            <select
              value={spec.table}
              onChange={(e) =>
                patch({ table: e.target.value, filters: [], groupBy: "", measureColumn: "" })
              }
              className={selectCls}
            >
              {TABLES.map((t) => (
                <option key={t.name} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>

            {["average", "sum", "min_max"].includes(spec.mode) ? (
              <>
                <span className="text-muted-foreground">of</span>
                <select
                  value={spec.measureColumn}
                  onChange={(e) => patch({ measureColumn: e.target.value })}
                  className={selectCls}
                >
                  <option value="">choose a number column…</option>
                  {numerics.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </>
            ) : null}

            {spec.mode !== "rows" ? (
              <>
                <span className="text-muted-foreground">broken down by</span>
                <select
                  value={spec.groupBy}
                  onChange={(e) => patch({ groupBy: e.target.value })}
                  className={selectCls}
                >
                  <option value="">nothing (one total)</option>
                  {columns.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </>
            ) : null}
          </div>

          <div className="space-y-2">
            {spec.filters.map((f, i) => {
              const op = FILTER_OPS.find((o) => o.value === f.op);
              return (
                <div key={i} className="flex flex-wrap items-center gap-2 text-[12.5px]">
                  <span className="text-muted-foreground">only where</span>
                  <select
                    value={f.column}
                    onChange={(e) => {
                      const next = [...spec.filters];
                      next[i] = { ...f, column: e.target.value };
                      patch({ filters: next });
                    }}
                    className={selectCls}
                  >
                    {columns.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <select
                    value={f.op}
                    onChange={(e) => {
                      const next = [...spec.filters];
                      next[i] = { ...f, op: e.target.value as BuilderSpec["filters"][0]["op"] };
                      patch({ filters: next });
                    }}
                    className={selectCls}
                  >
                    {FILTER_OPS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  {op?.needsValue ? (
                    <input
                      value={f.value}
                      onChange={(e) => {
                        const next = [...spec.filters];
                        next[i] = { ...f, value: e.target.value };
                        patch({ filters: next });
                      }}
                      placeholder="value"
                      className={cn(selectCls, "w-40")}
                    />
                  ) : null}
                  <button
                    type="button"
                    onClick={() => patch({ filters: spec.filters.filter((_, j) => j !== i) })}
                    className="text-muted-foreground hover:text-critical"
                    aria-label="Remove condition"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}
            <button
              type="button"
              onClick={() =>
                patch({
                  filters: [
                    ...spec.filters,
                    { column: columns[0] ?? "", op: "equals", value: "" },
                  ],
                })
              }
              className="flex items-center gap-1.5 rounded-md border border-border bg-surface px-2.5 py-1.5 text-[12px] font-medium hover:bg-surface-strong"
            >
              <Plus className="h-3.5 w-3.5" /> Add a condition
            </button>
          </div>

          <p className="text-[12.5px] text-muted-foreground">{describeSpec(spec)}</p>

          <pre className="overflow-x-auto rounded bg-surface-strong/60 p-2.5 font-mono text-[12px] leading-relaxed">
            {builtSql}
          </pre>

          <button
            type="button"
            onClick={() => {
              onUse(builtSql);
              toast.success("Query loaded into the editor");
            }}
            className="rounded-md bg-primary px-3 py-1.5 text-[12px] font-medium text-primary-foreground"
          >
            Use this query
          </button>
        </div>
      )}
    </Panel>
  );
}
