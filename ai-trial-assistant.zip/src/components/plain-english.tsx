import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { BookOpen, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "trialassist.plainEnglish";

interface PlainCtx {
  plain: boolean;
  toggle: () => void;
  set: (v: boolean) => void;
}

const Ctx = createContext<PlainCtx>({ plain: false, toggle: () => {}, set: () => {} });

export function PlainEnglishProvider({ children }: { children: ReactNode }) {
  const [plain, setPlain] = useState(false);

  useEffect(() => {
    try {
      setPlain(localStorage.getItem(STORAGE_KEY) === "1");
    } catch {
      /* ignore */
    }
  }, []);

  const set = useCallback((v: boolean) => {
    setPlain(v);
    try {
      localStorage.setItem(STORAGE_KEY, v ? "1" : "0");
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo(
    () => ({ plain, set, toggle: () => set(!plain) }),
    [plain, set],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function usePlainEnglish() {
  return useContext(Ctx);
}

/** The toggle button. Appears on every page header and in the top bar. */
export function PlainEnglishButton({ compact }: { compact?: boolean }) {
  const { plain, toggle } = usePlainEnglish();
  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={plain}
      title="Turn the technical wording on this page into everyday language"
      className={cn(
        "flex shrink-0 items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[12px] font-medium transition-colors",
        plain
          ? "border-primary/40 bg-accent text-accent-foreground"
          : "border-border bg-surface text-muted-foreground hover:text-foreground",
        compact && "px-2 py-1 text-[11px]",
      )}
    >
      <Sparkles className="h-3.5 w-3.5" />
      {plain ? "Plain English: on" : "Explain in plain English"}
    </button>
  );
}

/**
 * A friendly explanation box. Renders only when plain-English mode is on, so the
 * technical view stays untouched for the people who prefer it.
 */
export function PlainNote({
  title = "In plain English",
  lines,
  children,
  className,
}: {
  title?: string;
  lines?: string[];
  children?: ReactNode;
  className?: string;
}) {
  const { plain } = usePlainEnglish();
  if (!plain) return null;
  return (
    <div
      className={cn(
        "rounded-lg border border-primary/30 bg-accent/60 px-3.5 py-3 text-[13px] leading-relaxed text-accent-foreground",
        className,
      )}
    >
      <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold tracking-[0.07em] uppercase">
        <BookOpen className="h-3 w-3" /> {title}
      </div>
      {lines?.length ? (
        <ul className="space-y-1.5">
          {lines.map((l, i) => (
            <li key={i} className="flex gap-2">
              <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-primary" />
              <span>{l}</span>
            </li>
          ))}
        </ul>
      ) : null}
      {children}
    </div>
  );
}
