import { useState } from "react";
import {
  ChevronRight,
  Database,
  FileText,
  Activity,
  ShieldAlert,
  type LucideIcon,
} from "lucide-react";
import { TOOL_LABELS, type ToolName, type TraceStep } from "@/lib/orchestrator";
import { citationFor } from "@/lib/docs";
import { DataGrid } from "./data-grid";
import { PlainNote } from "./plain-english";
import { explainStep } from "@/lib/plain";
import { cn } from "@/lib/utils";

const TOOL_ICONS: Record<ToolName, LucideIcon> = {
  sql_query: Database,
  search_documentation: FileText,
  run_survival_analysis: Activity,
  data_quality_check: ShieldAlert,
};

export function TraceView({ steps, running }: { steps: TraceStep[]; running?: boolean }) {
  if (steps.length === 0 && !running) return null;
  return (
    <div className="space-y-2">
      <div className="label-caps">Execution trace</div>
      <ol className="space-y-2">
        {steps.map((step) => (
          <TraceStepCard key={`${step.index}-${step.tool}`} step={step} />
        ))}
      </ol>
      {running ? (
        <div className="flex items-center gap-2 rounded-lg border border-dashed border-border px-3 py-2.5 text-[12px] text-muted-foreground">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
          Selecting the next tool…
        </div>
      ) : null}
    </div>
  );
}

function TraceStepCard({ step }: { step: TraceStep }) {
  const [open, setOpen] = useState(false);
  const Icon = TOOL_ICONS[step.tool];
  const failed = Boolean(step.result.error);

  return (
    <li className="overflow-hidden rounded-lg border border-border bg-surface">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start gap-3 px-3 py-2.5 text-left transition-colors hover:bg-surface-strong"
      >
        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border border-border bg-surface-strong text-[10px] font-semibold tnum">
          {step.index}
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded border px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.05em] uppercase",
                failed
                  ? "border-critical/40 bg-critical/10 text-critical"
                  : "border-primary/30 bg-accent text-accent-foreground",
              )}
            >
              <Icon className="h-3 w-3" />
              {TOOL_LABELS[step.tool]}
            </span>
            <span className="text-[12px] font-medium">{step.result.summary}</span>
            <span className="text-[11px] text-muted-foreground tnum">{step.durationMs} ms</span>
          </span>
          <span className="mt-1 block text-[11.5px] leading-relaxed text-muted-foreground">
            {step.rationale}
          </span>
        </span>
        <ChevronRight
          className={cn(
            "mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform",
            open && "rotate-90",
          )}
        />
      </button>

      {open ? (
        <div className="space-y-3 border-t border-border bg-surface-strong/60 px-3 py-3">
          <PlainNote title="What this step did" lines={[explainStep(step)]} />

          {step.result.error ? (
            <p className="rounded border border-critical/40 bg-critical/10 px-2.5 py-2 font-mono text-[12px] text-critical">
              {step.result.error}
            </p>
          ) : null}

          {step.sql ? (
            <div>
              <div className="label-caps mb-1">Generated SQL</div>
              <pre className="overflow-x-auto rounded border border-border bg-surface p-2.5 font-mono text-[11.5px] leading-relaxed whitespace-pre-wrap">
                {step.sql}
              </pre>
            </div>
          ) : null}

          {step.result.metrics?.length ? (
            <div>
              <div className="label-caps mb-1">Computed values</div>
              <dl className="grid gap-x-6 gap-y-1 sm:grid-cols-2">
                {step.result.metrics.map((m) => (
                  <div
                    key={m.label}
                    className="flex items-baseline justify-between gap-3 text-[12px]"
                  >
                    <dt className="text-muted-foreground">{m.label}</dt>
                    <dd className="font-medium tnum">{m.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          ) : null}

          {step.result.rows?.length ? (
            <div>
              <div className="label-caps mb-1">
                Rows{" "}
                {step.result.rowCount !== undefined
                  ? `(${step.result.rows.length} of ${step.result.rowCount}${step.result.truncated ? ", truncated" : ""})`
                  : null}
              </div>
              <DataGrid
                columns={step.result.columns ?? Object.keys(step.result.rows[0] ?? {})}
                rows={step.result.rows.slice(0, 25)}
                maxHeight={260}
              />
            </div>
          ) : null}

          {step.result.hits?.length ? (
            <div className="space-y-2">
              <div className="label-caps">Retrieved passages</div>
              {step.result.hits.map((hit) => (
                <div
                  key={`${hit.docId}-${hit.section}`}
                  className="rounded border border-border bg-surface p-2.5"
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="text-[11.5px] font-semibold">{citationFor(hit)}</span>
                    <span className="text-[10.5px] text-muted-foreground tnum">
                      score {hit.score}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-muted-foreground">
                    {hit.snippet}
                  </p>
                </div>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
    </li>
  );
}
