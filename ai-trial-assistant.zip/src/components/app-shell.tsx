import { Link } from "@tanstack/react-router";
import {
  Activity,
  Database,
  FileText,
  MessageSquareText,
  ShieldAlert,
  Settings2,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";
import { useWarehouse } from "./warehouse-provider";
import { PlainEnglishButton } from "./plain-english";

const NAV: { to: string; label: string; icon: LucideIcon }[] = [
  { to: "/", label: "Query Assistant", icon: MessageSquareText },
  { to: "/survival", label: "Survival Analysis", icon: Activity },
  { to: "/sql", label: "SQL Workbench", icon: Database },
  { to: "/documents", label: "Study Documents", icon: FileText },
  { to: "/quality", label: "Data Quality", icon: ShieldAlert },
  { to: "/settings", label: "Settings", icon: Settings2 },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { loading, error } = useWarehouse();

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-surface/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-6 px-5">
          <Link to="/" className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-[6px] bg-primary text-[11px] font-bold tracking-tight text-primary-foreground">
              TA
            </span>
            <span className="flex flex-col leading-none">
              <span className="text-[13px] font-semibold tracking-tight">TrialAssist</span>
              <span className="mt-0.5 text-[10px] font-medium tracking-[0.09em] text-muted-foreground uppercase">
                ONC-501-301
              </span>
            </span>
          </Link>

          <nav className="hidden items-center gap-0.5 md:flex">
            {NAV.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                activeOptions={{ exact: to === "/" }}
                activeProps={{ className: "bg-accent text-accent-foreground" }}
                inactiveProps={{
                  className: "text-muted-foreground hover:bg-secondary hover:text-foreground",
                }}
                className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors"
              >
                <Icon className="h-3.5 w-3.5" strokeWidth={2} />
                {label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <PlainEnglishButton compact />
            <WarehouseBadge loading={loading} error={error} />
          </div>
        </div>

        <nav className="flex gap-1 overflow-x-auto border-t border-border px-4 py-1.5 md:hidden">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              activeOptions={{ exact: to === "/" }}
              activeProps={{ className: "bg-accent text-accent-foreground" }}
              inactiveProps={{ className: "text-muted-foreground" }}
              className="flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium"
            >
              <Icon className="h-3.5 w-3.5" />
              {label}
            </Link>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-[1400px] px-5 py-7">{children}</main>

      <footer className="mx-auto max-w-[1400px] px-5 pb-10 text-[11px] leading-relaxed text-muted-foreground">
        Synthetic demonstration dataset for study ONC-501-301. Not for clinical, regulatory, or
        submission use. All figures are computed live from the loaded warehouse.
      </footer>
    </div>
  );
}

function WarehouseBadge({ loading, error }: { loading: boolean; error: string | null }) {
  const tone = error
    ? "border-critical/40 bg-critical/10 text-critical"
    : loading
      ? "border-border bg-secondary text-muted-foreground"
      : "border-primary/30 bg-accent text-accent-foreground";
  const dot = error ? "bg-critical" : loading ? "bg-muted-foreground animate-pulse" : "bg-primary";
  return (
    <span
      className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium ${tone}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      {error ? "Warehouse error" : loading ? "Loading warehouse…" : "Warehouse ready"}
    </span>
  );
}
