import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { getWarehouse, type Warehouse } from "@/lib/warehouse";

interface WarehouseState {
  warehouse: Warehouse | null;
  loading: boolean;
  error: string | null;
}

const WarehouseContext = createContext<WarehouseState>({
  warehouse: null,
  loading: true,
  error: null,
});

export function WarehouseProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WarehouseState>({
    warehouse: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;
    getWarehouse()
      .then((warehouse) => {
        if (!cancelled) setState({ warehouse, loading: false, error: null });
      })
      .catch((error: Error) => {
        if (!cancelled) setState({ warehouse: null, loading: false, error: error.message });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return <WarehouseContext.Provider value={state}>{children}</WarehouseContext.Provider>;
}

export function useWarehouse() {
  return useContext(WarehouseContext);
}
