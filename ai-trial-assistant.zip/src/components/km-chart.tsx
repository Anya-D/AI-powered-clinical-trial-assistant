import { useId, useMemo, useState } from "react";
import { daysToMonths, survivalAt, type KMCurve } from "@/lib/stats";

const ARM_COLORS: Record<string, string> = {
  "ONC-501": "var(--arm-treatment)",
  "Standard of Care": "var(--arm-control)",
};

interface Props {
  curves: KMCurve[];
  showCi: boolean;
  showCensors: boolean;
  showMedian: boolean;
  xUnit: "days" | "months";
  height?: number;
}

const M = { top: 16, right: 20, bottom: 44, left: 56 };

export function KMChart({ curves, showCi, showCensors, showMedian, xUnit, height = 380 }: Props) {
  const uid = useId().replace(/:/g, "");
  const [hover, setHover] = useState<{ x: number; time: number } | null>(null);
  const width = 760;
  const plotW = width - M.left - M.right;
  const plotH = height - M.top - M.bottom;

  const maxTime = Math.max(...curves.map((c) => c.maxTime), 1);
  const toX = (t: number) => M.left + (t / maxTime) * plotW;
  const toY = (s: number) => M.top + (1 - s) * plotH;
  const fmtX = (t: number) =>
    xUnit === "months" ? daysToMonths(t).toFixed(0) : String(Math.round(t));

  const xTicks = useMemo(() => {
    const count = 8;
    return Array.from({ length: count + 1 }, (_, i) => (maxTime / count) * i);
  }, [maxTime]);
  const yTicks = [0, 0.25, 0.5, 0.75, 1];

  const stepPath = (curve: KMCurve) => {
    const pts = curve.points;
    let d = `M ${toX(0)} ${toY(1)}`;
    for (const p of pts) {
      d += ` L ${toX(p.time)} ${toY(prevSurvival(pts, p.time))} L ${toX(p.time)} ${toY(p.survival)}`;
    }
    d += ` L ${toX(curve.maxTime)} ${toY(pts[pts.length - 1]!.survival)}`;
    return d;
  };

  const ciPath = (curve: KMCurve) => {
    const pts = curve.points;
    let up = `M ${toX(0)} ${toY(1)}`;
    for (const p of pts) up += ` L ${toX(p.time)} ${toY(p.ciUpper)}`;
    up += ` L ${toX(curve.maxTime)} ${toY(pts[pts.length - 1]!.ciUpper)}`;
    let down = ` L ${toX(curve.maxTime)} ${toY(pts[pts.length - 1]!.ciLower)}`;
    for (let i = pts.length - 1; i >= 0; i--)
      down += ` L ${toX(pts[i]!.time)} ${toY(pts[i]!.ciLower)}`;
    return `${up}${down} Z`;
  };

  const hoverTime = hover?.time ?? null;

  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full"
        role="img"
        aria-label="Kaplan-Meier survival curves by treatment arm"
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const px = ((e.clientX - rect.left) / rect.width) * width;
          if (px < M.left || px > width - M.right) return setHover(null);
          setHover({ x: px, time: ((px - M.left) / plotW) * maxTime });
        }}
        onMouseLeave={() => setHover(null)}
      >
        <defs>
          {curves.map((c) => (
            <clipPath key={c.label} id={`${uid}-clip`}>
              <rect x={M.left} y={M.top} width={plotW} height={plotH} />
            </clipPath>
          ))}
        </defs>

        {yTicks.map((t) => (
          <g key={t}>
            <line
              x1={M.left}
              x2={width - M.right}
              y1={toY(t)}
              y2={toY(t)}
              stroke="var(--grid)"
              strokeWidth={1}
            />
            <text
              x={M.left - 10}
              y={toY(t) + 4}
              textAnchor="end"
              className="fill-[var(--muted-foreground)] text-[11px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {(t * 100).toFixed(0)}%
            </text>
          </g>
        ))}

        {xTicks.map((t) => (
          <g key={t}>
            <line
              x1={toX(t)}
              x2={toX(t)}
              y1={M.top}
              y2={M.top + plotH}
              stroke="var(--grid)"
              strokeWidth={0.5}
            />
            <text
              x={toX(t)}
              y={M.top + plotH + 18}
              textAnchor="middle"
              className="fill-[var(--muted-foreground)] text-[11px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {fmtX(t)}
            </text>
          </g>
        ))}
        <text
          x={M.left + plotW / 2}
          y={height - 6}
          textAnchor="middle"
          className="fill-[var(--muted-foreground)] text-[11px]"
        >
          Time since randomization ({xUnit})
        </text>
        <text
          x={14}
          y={M.top + plotH / 2}
          textAnchor="middle"
          transform={`rotate(-90 14 ${M.top + plotH / 2})`}
          className="fill-[var(--muted-foreground)] text-[11px]"
        >
          Survival probability
        </text>

        <g clipPath={`url(#${uid}-clip)`}>
          {showCi
            ? curves.map((c) => (
                <path
                  key={`ci-${c.label}`}
                  d={ciPath(c)}
                  fill={ARM_COLORS[c.label]}
                  opacity={0.11}
                />
              ))
            : null}

          {showMedian
            ? curves
                .filter((c) => c.median != null)
                .map((c) => (
                  <g key={`med-${c.label}`}>
                    <line
                      x1={toX(c.median!)}
                      x2={toX(c.median!)}
                      y1={toY(0.5)}
                      y2={toY(0)}
                      stroke={ARM_COLORS[c.label]}
                      strokeWidth={1}
                      strokeDasharray="4 3"
                      opacity={0.75}
                    />
                  </g>
                ))
            : null}

          {showMedian ? (
            <line
              x1={M.left}
              x2={width - M.right}
              y1={toY(0.5)}
              y2={toY(0.5)}
              stroke="var(--muted-foreground)"
              strokeWidth={1}
              strokeDasharray="4 3"
              opacity={0.5}
            />
          ) : null}

          {curves.map((c) => (
            <path
              key={`line-${c.label}`}
              d={stepPath(c)}
              fill="none"
              stroke={ARM_COLORS[c.label]}
              strokeWidth={2}
              strokeLinejoin="round"
            />
          ))}

          {showCensors
            ? curves.map((c) => (
                <g key={`cen-${c.label}`} stroke={ARM_COLORS[c.label]} strokeWidth={1.4}>
                  {c.censorMarks.map((m, i) => (
                    <line
                      key={i}
                      x1={toX(m.time)}
                      x2={toX(m.time)}
                      y1={toY(m.survival) - 4}
                      y2={toY(m.survival) + 4}
                    />
                  ))}
                </g>
              ))
            : null}

          {hoverTime != null ? (
            <line
              x1={toX(hoverTime)}
              x2={toX(hoverTime)}
              y1={M.top}
              y2={M.top + plotH}
              stroke="var(--foreground)"
              strokeWidth={1}
              opacity={0.35}
            />
          ) : null}

          {hoverTime != null
            ? curves.map((c) => (
                <circle
                  key={`dot-${c.label}`}
                  cx={toX(hoverTime)}
                  cy={toY(survivalAt(c.points, hoverTime))}
                  r={3.5}
                  fill={ARM_COLORS[c.label]}
                />
              ))
            : null}
        </g>

        <line x1={M.left} x2={M.left} y1={M.top} y2={M.top + plotH} stroke="var(--border)" />
        <line
          x1={M.left}
          x2={width - M.right}
          y1={M.top + plotH}
          y2={M.top + plotH}
          stroke="var(--border)"
        />
      </svg>

      <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-4">
          {curves.map((c) => (
            <span key={c.label} className="flex items-center gap-1.5 text-[12px]">
              <span
                className="inline-block h-0.5 w-5 rounded"
                style={{ backgroundColor: ARM_COLORS[c.label] }}
              />
              {c.label}
              <span className="text-muted-foreground tnum">
                (n = {c.n}, {c.events} events)
              </span>
            </span>
          ))}
        </div>
        {hoverTime != null ? (
          <span className="text-[12px] text-muted-foreground tnum">
            t = {fmtX(hoverTime)} {xUnit} ·{" "}
            {curves
              .map((c) => `${c.label}: ${(survivalAt(c.points, hoverTime) * 100).toFixed(1)}%`)
              .join("  ·  ")}
          </span>
        ) : null}
      </div>
    </div>
  );
}

function prevSurvival(points: KMCurve["points"], time: number): number {
  let s = 1;
  for (const p of points) {
    if (p.time >= time) break;
    s = p.survival;
  }
  return s;
}

export function AtRiskTable({ curves, xUnit }: { curves: KMCurve[]; xUnit: "days" | "months" }) {
  const maxTime = Math.max(...curves.map((c) => c.maxTime), 1);
  const stops = Array.from({ length: 9 }, (_, i) => (maxTime / 8) * i);
  return (
    <div className="overflow-x-auto">
      <table className="data-table">
        <thead>
          <tr>
            <th>At risk ({xUnit})</th>
            {stops.map((t) => (
              <th key={t} className="text-right">
                {xUnit === "months" ? daysToMonths(t).toFixed(0) : Math.round(t)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {curves.map((c) => (
            <tr key={c.label}>
              <td className="font-medium">{c.label}</td>
              {stops.map((t) => {
                const atRisk = c.points
                  .filter((p) => p.time >= t)
                  .reduce((m, p) => Math.max(m, p.atRisk), 0);
                return (
                  <td key={t} className="text-right tnum">
                    {t === 0 ? c.n : atRisk}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
